﻿namespace Centro_de_cumputo
{
    partial class PaginaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pcActiva = new System.Windows.Forms.PictureBox();
            this.pcInactiva = new System.Windows.Forms.PictureBox();
            this.panelCodigo = new System.Windows.Forms.Panel();
            this.btnQuitar = new System.Windows.Forms.Button();
            this.lblTexto3 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.listaCodigo = new System.Windows.Forms.ListBox();
            this.lblTexto2 = new System.Windows.Forms.Label();
            this.lblCerrar = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.lblTexto1 = new System.Windows.Forms.Label();
            this.btnDevolver = new System.Windows.Forms.Button();
            this.pc4 = new System.Windows.Forms.PictureBox();
            this.pc3 = new System.Windows.Forms.PictureBox();
            this.pc8 = new System.Windows.Forms.PictureBox();
            this.pc7 = new System.Windows.Forms.PictureBox();
            this.pc6 = new System.Windows.Forms.PictureBox();
            this.pc5 = new System.Windows.Forms.PictureBox();
            this.pc16 = new System.Windows.Forms.PictureBox();
            this.pc15 = new System.Windows.Forms.PictureBox();
            this.pc14 = new System.Windows.Forms.PictureBox();
            this.pc13 = new System.Windows.Forms.PictureBox();
            this.pc12 = new System.Windows.Forms.PictureBox();
            this.pc11 = new System.Windows.Forms.PictureBox();
            this.pc10 = new System.Windows.Forms.PictureBox();
            this.pc9 = new System.Windows.Forms.PictureBox();
            this.pc32 = new System.Windows.Forms.PictureBox();
            this.pc31 = new System.Windows.Forms.PictureBox();
            this.pc30 = new System.Windows.Forms.PictureBox();
            this.pc29 = new System.Windows.Forms.PictureBox();
            this.pc28 = new System.Windows.Forms.PictureBox();
            this.pc27 = new System.Windows.Forms.PictureBox();
            this.pc26 = new System.Windows.Forms.PictureBox();
            this.pc25 = new System.Windows.Forms.PictureBox();
            this.pc24 = new System.Windows.Forms.PictureBox();
            this.pc23 = new System.Windows.Forms.PictureBox();
            this.pc22 = new System.Windows.Forms.PictureBox();
            this.pc21 = new System.Windows.Forms.PictureBox();
            this.pc20 = new System.Windows.Forms.PictureBox();
            this.pc19 = new System.Windows.Forms.PictureBox();
            this.pc18 = new System.Windows.Forms.PictureBox();
            this.pc17 = new System.Windows.Forms.PictureBox();
            this.pc56 = new System.Windows.Forms.PictureBox();
            this.pc55 = new System.Windows.Forms.PictureBox();
            this.pc54 = new System.Windows.Forms.PictureBox();
            this.pc53 = new System.Windows.Forms.PictureBox();
            this.pc52 = new System.Windows.Forms.PictureBox();
            this.pc51 = new System.Windows.Forms.PictureBox();
            this.pc50 = new System.Windows.Forms.PictureBox();
            this.pc49 = new System.Windows.Forms.PictureBox();
            this.pc48 = new System.Windows.Forms.PictureBox();
            this.pc47 = new System.Windows.Forms.PictureBox();
            this.pc46 = new System.Windows.Forms.PictureBox();
            this.pc45 = new System.Windows.Forms.PictureBox();
            this.pc44 = new System.Windows.Forms.PictureBox();
            this.pc43 = new System.Windows.Forms.PictureBox();
            this.pc42 = new System.Windows.Forms.PictureBox();
            this.pc41 = new System.Windows.Forms.PictureBox();
            this.pc40 = new System.Windows.Forms.PictureBox();
            this.pc39 = new System.Windows.Forms.PictureBox();
            this.pc38 = new System.Windows.Forms.PictureBox();
            this.pc37 = new System.Windows.Forms.PictureBox();
            this.pc36 = new System.Windows.Forms.PictureBox();
            this.pc35 = new System.Windows.Forms.PictureBox();
            this.pc34 = new System.Windows.Forms.PictureBox();
            this.pc33 = new System.Windows.Forms.PictureBox();
            this.RevisionPC = new System.Windows.Forms.Timer(this.components);
            this.pc1 = new System.Windows.Forms.PictureBox();
            this.pc2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNombre1 = new System.Windows.Forms.Label();
            this.lblNombre2 = new System.Windows.Forms.Label();
            this.lblNombre3 = new System.Windows.Forms.Label();
            this.lblNombre6 = new System.Windows.Forms.Label();
            this.lblNombre5 = new System.Windows.Forms.Label();
            this.lblNombre4 = new System.Windows.Forms.Label();
            this.lblNombre8 = new System.Windows.Forms.Label();
            this.lblNombre7 = new System.Windows.Forms.Label();
            this.lblNombre16 = new System.Windows.Forms.Label();
            this.lblNombre15 = new System.Windows.Forms.Label();
            this.lblNombre14 = new System.Windows.Forms.Label();
            this.lblNombre13 = new System.Windows.Forms.Label();
            this.lblNombre12 = new System.Windows.Forms.Label();
            this.lblNombre11 = new System.Windows.Forms.Label();
            this.lblNombre10 = new System.Windows.Forms.Label();
            this.lblNombre9 = new System.Windows.Forms.Label();
            this.lblNombre24 = new System.Windows.Forms.Label();
            this.lblNombre23 = new System.Windows.Forms.Label();
            this.lblNombre22 = new System.Windows.Forms.Label();
            this.lblNombre21 = new System.Windows.Forms.Label();
            this.lblNombre20 = new System.Windows.Forms.Label();
            this.lblNombre19 = new System.Windows.Forms.Label();
            this.lblNombre18 = new System.Windows.Forms.Label();
            this.lblNombre17 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.lblMensaje = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcActiva)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcInactiva)).BeginInit();
            this.panelCodigo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pc4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc2)).BeginInit();
            this.SuspendLayout();
            // 
            // pcActiva
            // 
            this.pcActiva.BackColor = System.Drawing.Color.Transparent;
            this.pcActiva.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pcActiva.Location = new System.Drawing.Point(220, 843);
            this.pcActiva.Name = "pcActiva";
            this.pcActiva.Size = new System.Drawing.Size(87, 54);
            this.pcActiva.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcActiva.TabIndex = 1;
            this.pcActiva.TabStop = false;
            this.pcActiva.Visible = false;
            // 
            // pcInactiva
            // 
            this.pcInactiva.BackColor = System.Drawing.Color.Transparent;
            this.pcInactiva.Image = global::Centro_de_cumputo.Properties.Resources.opt3020ocupada;
            this.pcInactiva.Location = new System.Drawing.Point(127, 843);
            this.pcInactiva.Name = "pcInactiva";
            this.pcInactiva.Size = new System.Drawing.Size(87, 54);
            this.pcInactiva.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcInactiva.TabIndex = 2;
            this.pcInactiva.TabStop = false;
            this.pcInactiva.Visible = false;
            // 
            // panelCodigo
            // 
            this.panelCodigo.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panelCodigo.BackgroundImage = global::Centro_de_cumputo.Properties.Resources.gradient__1_;
            this.panelCodigo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelCodigo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCodigo.Controls.Add(this.btnQuitar);
            this.panelCodigo.Controls.Add(this.lblTexto3);
            this.panelCodigo.Controls.Add(this.btnAceptar);
            this.panelCodigo.Controls.Add(this.listaCodigo);
            this.panelCodigo.Controls.Add(this.lblTexto2);
            this.panelCodigo.Controls.Add(this.lblCerrar);
            this.panelCodigo.Controls.Add(this.txtCodigo);
            this.panelCodigo.Controls.Add(this.lblTexto1);
            this.panelCodigo.Controls.Add(this.btnDevolver);
            this.panelCodigo.Location = new System.Drawing.Point(1238, 13);
            this.panelCodigo.Name = "panelCodigo";
            this.panelCodigo.Size = new System.Drawing.Size(371, 884);
            this.panelCodigo.TabIndex = 3;
            // 
            // btnQuitar
            // 
            this.btnQuitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitar.Location = new System.Drawing.Point(243, 410);
            this.btnQuitar.Name = "btnQuitar";
            this.btnQuitar.Size = new System.Drawing.Size(110, 45);
            this.btnQuitar.TabIndex = 10;
            this.btnQuitar.Text = "Quitar";
            this.btnQuitar.UseVisualStyleBackColor = true;
            this.btnQuitar.Click += new System.EventHandler(this.btnQuitar_Click);
            // 
            // lblTexto3
            // 
            this.lblTexto3.AutoSize = true;
            this.lblTexto3.BackColor = System.Drawing.Color.Transparent;
            this.lblTexto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto3.ForeColor = System.Drawing.Color.White;
            this.lblTexto3.Location = new System.Drawing.Point(10, 71);
            this.lblTexto3.Name = "lblTexto3";
            this.lblTexto3.Size = new System.Drawing.Size(126, 36);
            this.lblTexto3.TabIndex = 9;
            this.lblTexto3.Text = "Codigos";
            // 
            // btnAceptar
            // 
            this.btnAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.Location = new System.Drawing.Point(3, 772);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(180, 70);
            this.btnAceptar.TabIndex = 8;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // listaCodigo
            // 
            this.listaCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listaCodigo.FormattingEnabled = true;
            this.listaCodigo.ItemHeight = 31;
            this.listaCodigo.Location = new System.Drawing.Point(15, 122);
            this.listaCodigo.Name = "listaCodigo";
            this.listaCodigo.Size = new System.Drawing.Size(222, 562);
            this.listaCodigo.TabIndex = 7;
            // 
            // lblTexto2
            // 
            this.lblTexto2.AutoSize = true;
            this.lblTexto2.BackColor = System.Drawing.Color.Transparent;
            this.lblTexto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto2.ForeColor = System.Drawing.Color.White;
            this.lblTexto2.Location = new System.Drawing.Point(199, 702);
            this.lblTexto2.Name = "lblTexto2";
            this.lblTexto2.Size = new System.Drawing.Size(0, 36);
            this.lblTexto2.TabIndex = 5;
            // 
            // lblCerrar
            // 
            this.lblCerrar.AutoSize = true;
            this.lblCerrar.BackColor = System.Drawing.Color.Transparent;
            this.lblCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCerrar.ForeColor = System.Drawing.Color.White;
            this.lblCerrar.Location = new System.Drawing.Point(324, 3);
            this.lblCerrar.Name = "lblCerrar";
            this.lblCerrar.Size = new System.Drawing.Size(27, 25);
            this.lblCerrar.TabIndex = 4;
            this.lblCerrar.Text = "X";
            this.lblCerrar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCerrar.Visible = false;
            this.lblCerrar.Click += new System.EventHandler(this.lblCerrar_Click);
            this.lblCerrar.MouseEnter += new System.EventHandler(this.lblCerrar_MouseEnter);
            this.lblCerrar.MouseLeave += new System.EventHandler(this.lblCerrar_MouseLeave);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigo.Location = new System.Drawing.Point(147, 71);
            this.txtCodigo.MaxLength = 8;
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(204, 41);
            this.txtCodigo.TabIndex = 1;
            this.txtCodigo.TextChanged += new System.EventHandler(this.txtCodigo_TextChanged);
            this.txtCodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigo_KeyPress);
            // 
            // lblTexto1
            // 
            this.lblTexto1.AutoSize = true;
            this.lblTexto1.BackColor = System.Drawing.Color.Transparent;
            this.lblTexto1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto1.ForeColor = System.Drawing.Color.White;
            this.lblTexto1.Location = new System.Drawing.Point(9, 702);
            this.lblTexto1.Name = "lblTexto1";
            this.lblTexto1.Size = new System.Drawing.Size(134, 36);
            this.lblTexto1.TabIndex = 0;
            this.lblTexto1.Text = "Cantidad";
            // 
            // btnDevolver
            // 
            this.btnDevolver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDevolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDevolver.FlatAppearance.BorderSize = 0;
            this.btnDevolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevolver.Font = new System.Drawing.Font("MS PGothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDevolver.ForeColor = System.Drawing.Color.Black;
            this.btnDevolver.Location = new System.Drawing.Point(189, 772);
            this.btnDevolver.Name = "btnDevolver";
            this.btnDevolver.Size = new System.Drawing.Size(164, 70);
            this.btnDevolver.TabIndex = 4;
            this.btnDevolver.Text = "Devolver";
            this.btnDevolver.UseVisualStyleBackColor = false;
            this.btnDevolver.Click += new System.EventHandler(this.btnDevolver_Click);
            // 
            // pc4
            // 
            this.pc4.BackColor = System.Drawing.Color.Transparent;
            this.pc4.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc4.Location = new System.Drawing.Point(462, 13);
            this.pc4.Name = "pc4";
            this.pc4.Size = new System.Drawing.Size(125, 80);
            this.pc4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc4.TabIndex = 7;
            this.pc4.TabStop = false;
            this.pc4.Click += new System.EventHandler(this.pc4_Click);
            // 
            // pc3
            // 
            this.pc3.BackColor = System.Drawing.Color.Transparent;
            this.pc3.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc3.Location = new System.Drawing.Point(313, 12);
            this.pc3.Name = "pc3";
            this.pc3.Size = new System.Drawing.Size(125, 80);
            this.pc3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc3.TabIndex = 6;
            this.pc3.TabStop = false;
            this.pc3.Click += new System.EventHandler(this.pc3_Click);
            // 
            // pc8
            // 
            this.pc8.BackColor = System.Drawing.Color.Transparent;
            this.pc8.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc8.Location = new System.Drawing.Point(1065, 13);
            this.pc8.Name = "pc8";
            this.pc8.Size = new System.Drawing.Size(125, 80);
            this.pc8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc8.TabIndex = 11;
            this.pc8.TabStop = false;
            this.pc8.Click += new System.EventHandler(this.pc8_Click);
            // 
            // pc7
            // 
            this.pc7.BackColor = System.Drawing.Color.Transparent;
            this.pc7.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc7.Location = new System.Drawing.Point(917, 12);
            this.pc7.Name = "pc7";
            this.pc7.Size = new System.Drawing.Size(125, 80);
            this.pc7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc7.TabIndex = 10;
            this.pc7.TabStop = false;
            this.pc7.Click += new System.EventHandler(this.pc7_Click);
            // 
            // pc6
            // 
            this.pc6.BackColor = System.Drawing.Color.Transparent;
            this.pc6.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc6.Location = new System.Drawing.Point(765, 12);
            this.pc6.Name = "pc6";
            this.pc6.Size = new System.Drawing.Size(125, 80);
            this.pc6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc6.TabIndex = 9;
            this.pc6.TabStop = false;
            this.pc6.Click += new System.EventHandler(this.pc6_Click);
            // 
            // pc5
            // 
            this.pc5.BackColor = System.Drawing.Color.Transparent;
            this.pc5.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc5.Location = new System.Drawing.Point(614, 12);
            this.pc5.Name = "pc5";
            this.pc5.Size = new System.Drawing.Size(125, 80);
            this.pc5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc5.TabIndex = 8;
            this.pc5.TabStop = false;
            this.pc5.Click += new System.EventHandler(this.pc5_Click);
            // 
            // pc16
            // 
            this.pc16.BackColor = System.Drawing.Color.Transparent;
            this.pc16.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc16.Location = new System.Drawing.Point(1065, 128);
            this.pc16.Name = "pc16";
            this.pc16.Size = new System.Drawing.Size(125, 80);
            this.pc16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc16.TabIndex = 19;
            this.pc16.TabStop = false;
            this.pc16.Click += new System.EventHandler(this.pc16_Click);
            // 
            // pc15
            // 
            this.pc15.BackColor = System.Drawing.Color.Transparent;
            this.pc15.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc15.Location = new System.Drawing.Point(917, 128);
            this.pc15.Name = "pc15";
            this.pc15.Size = new System.Drawing.Size(125, 80);
            this.pc15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc15.TabIndex = 18;
            this.pc15.TabStop = false;
            this.pc15.Click += new System.EventHandler(this.pc15_Click);
            // 
            // pc14
            // 
            this.pc14.BackColor = System.Drawing.Color.Transparent;
            this.pc14.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc14.Location = new System.Drawing.Point(765, 128);
            this.pc14.Name = "pc14";
            this.pc14.Size = new System.Drawing.Size(125, 80);
            this.pc14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc14.TabIndex = 17;
            this.pc14.TabStop = false;
            this.pc14.Click += new System.EventHandler(this.pc14_Click);
            // 
            // pc13
            // 
            this.pc13.BackColor = System.Drawing.Color.Transparent;
            this.pc13.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc13.Location = new System.Drawing.Point(614, 128);
            this.pc13.Name = "pc13";
            this.pc13.Size = new System.Drawing.Size(125, 80);
            this.pc13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc13.TabIndex = 16;
            this.pc13.TabStop = false;
            this.pc13.Click += new System.EventHandler(this.pc13_Click);
            // 
            // pc12
            // 
            this.pc12.BackColor = System.Drawing.Color.Transparent;
            this.pc12.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc12.Location = new System.Drawing.Point(462, 128);
            this.pc12.Name = "pc12";
            this.pc12.Size = new System.Drawing.Size(125, 80);
            this.pc12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc12.TabIndex = 15;
            this.pc12.TabStop = false;
            this.pc12.Click += new System.EventHandler(this.pc12_Click);
            // 
            // pc11
            // 
            this.pc11.BackColor = System.Drawing.Color.Transparent;
            this.pc11.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc11.Location = new System.Drawing.Point(313, 128);
            this.pc11.Name = "pc11";
            this.pc11.Size = new System.Drawing.Size(125, 80);
            this.pc11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc11.TabIndex = 14;
            this.pc11.TabStop = false;
            this.pc11.Click += new System.EventHandler(this.pc11_Click);
            // 
            // pc10
            // 
            this.pc10.BackColor = System.Drawing.Color.Transparent;
            this.pc10.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc10.Location = new System.Drawing.Point(161, 128);
            this.pc10.Name = "pc10";
            this.pc10.Size = new System.Drawing.Size(125, 80);
            this.pc10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc10.TabIndex = 13;
            this.pc10.TabStop = false;
            this.pc10.Click += new System.EventHandler(this.pc10_Click);
            // 
            // pc9
            // 
            this.pc9.BackColor = System.Drawing.Color.Transparent;
            this.pc9.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc9.Location = new System.Drawing.Point(12, 128);
            this.pc9.Name = "pc9";
            this.pc9.Size = new System.Drawing.Size(125, 80);
            this.pc9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc9.TabIndex = 12;
            this.pc9.TabStop = false;
            this.pc9.Click += new System.EventHandler(this.pc9_Click);
            // 
            // pc32
            // 
            this.pc32.BackColor = System.Drawing.Color.Transparent;
            this.pc32.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc32.Location = new System.Drawing.Point(1065, 358);
            this.pc32.Name = "pc32";
            this.pc32.Size = new System.Drawing.Size(125, 80);
            this.pc32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc32.TabIndex = 35;
            this.pc32.TabStop = false;
            this.pc32.Click += new System.EventHandler(this.pc32_Click);
            // 
            // pc31
            // 
            this.pc31.BackColor = System.Drawing.Color.Transparent;
            this.pc31.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc31.Location = new System.Drawing.Point(917, 358);
            this.pc31.Name = "pc31";
            this.pc31.Size = new System.Drawing.Size(125, 80);
            this.pc31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc31.TabIndex = 34;
            this.pc31.TabStop = false;
            this.pc31.Click += new System.EventHandler(this.pc31_Click);
            // 
            // pc30
            // 
            this.pc30.BackColor = System.Drawing.Color.Transparent;
            this.pc30.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc30.Location = new System.Drawing.Point(765, 358);
            this.pc30.Name = "pc30";
            this.pc30.Size = new System.Drawing.Size(125, 80);
            this.pc30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc30.TabIndex = 33;
            this.pc30.TabStop = false;
            this.pc30.Click += new System.EventHandler(this.pc30_Click);
            // 
            // pc29
            // 
            this.pc29.BackColor = System.Drawing.Color.Transparent;
            this.pc29.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc29.Location = new System.Drawing.Point(614, 358);
            this.pc29.Name = "pc29";
            this.pc29.Size = new System.Drawing.Size(125, 80);
            this.pc29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc29.TabIndex = 32;
            this.pc29.TabStop = false;
            this.pc29.Click += new System.EventHandler(this.pc29_Click);
            // 
            // pc28
            // 
            this.pc28.BackColor = System.Drawing.Color.Transparent;
            this.pc28.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc28.Location = new System.Drawing.Point(462, 358);
            this.pc28.Name = "pc28";
            this.pc28.Size = new System.Drawing.Size(125, 80);
            this.pc28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc28.TabIndex = 31;
            this.pc28.TabStop = false;
            this.pc28.Click += new System.EventHandler(this.pc28_Click);
            // 
            // pc27
            // 
            this.pc27.BackColor = System.Drawing.Color.Transparent;
            this.pc27.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc27.Location = new System.Drawing.Point(313, 358);
            this.pc27.Name = "pc27";
            this.pc27.Size = new System.Drawing.Size(125, 80);
            this.pc27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc27.TabIndex = 30;
            this.pc27.TabStop = false;
            this.pc27.Click += new System.EventHandler(this.pc27_Click);
            // 
            // pc26
            // 
            this.pc26.BackColor = System.Drawing.Color.Transparent;
            this.pc26.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc26.Location = new System.Drawing.Point(161, 358);
            this.pc26.Name = "pc26";
            this.pc26.Size = new System.Drawing.Size(125, 80);
            this.pc26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc26.TabIndex = 29;
            this.pc26.TabStop = false;
            this.pc26.Click += new System.EventHandler(this.pc26_Click);
            // 
            // pc25
            // 
            this.pc25.BackColor = System.Drawing.Color.Transparent;
            this.pc25.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc25.Location = new System.Drawing.Point(12, 358);
            this.pc25.Name = "pc25";
            this.pc25.Size = new System.Drawing.Size(125, 80);
            this.pc25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc25.TabIndex = 28;
            this.pc25.TabStop = false;
            this.pc25.Click += new System.EventHandler(this.pc25_Click);
            // 
            // pc24
            // 
            this.pc24.BackColor = System.Drawing.Color.Transparent;
            this.pc24.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc24.Location = new System.Drawing.Point(1065, 242);
            this.pc24.Name = "pc24";
            this.pc24.Size = new System.Drawing.Size(125, 80);
            this.pc24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc24.TabIndex = 27;
            this.pc24.TabStop = false;
            this.pc24.Click += new System.EventHandler(this.pc24_Click);
            // 
            // pc23
            // 
            this.pc23.BackColor = System.Drawing.Color.Transparent;
            this.pc23.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc23.Location = new System.Drawing.Point(917, 242);
            this.pc23.Name = "pc23";
            this.pc23.Size = new System.Drawing.Size(125, 80);
            this.pc23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc23.TabIndex = 26;
            this.pc23.TabStop = false;
            this.pc23.Click += new System.EventHandler(this.pc23_Click);
            // 
            // pc22
            // 
            this.pc22.BackColor = System.Drawing.Color.Transparent;
            this.pc22.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc22.Location = new System.Drawing.Point(765, 242);
            this.pc22.Name = "pc22";
            this.pc22.Size = new System.Drawing.Size(125, 80);
            this.pc22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc22.TabIndex = 25;
            this.pc22.TabStop = false;
            this.pc22.Click += new System.EventHandler(this.pc22_Click);
            // 
            // pc21
            // 
            this.pc21.BackColor = System.Drawing.Color.Transparent;
            this.pc21.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc21.Location = new System.Drawing.Point(614, 242);
            this.pc21.Name = "pc21";
            this.pc21.Size = new System.Drawing.Size(125, 80);
            this.pc21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc21.TabIndex = 24;
            this.pc21.TabStop = false;
            this.pc21.Click += new System.EventHandler(this.pc21_Click);
            // 
            // pc20
            // 
            this.pc20.BackColor = System.Drawing.Color.Transparent;
            this.pc20.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc20.Location = new System.Drawing.Point(462, 242);
            this.pc20.Name = "pc20";
            this.pc20.Size = new System.Drawing.Size(125, 80);
            this.pc20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc20.TabIndex = 23;
            this.pc20.TabStop = false;
            this.pc20.Click += new System.EventHandler(this.pc20_Click);
            // 
            // pc19
            // 
            this.pc19.BackColor = System.Drawing.Color.Transparent;
            this.pc19.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc19.Location = new System.Drawing.Point(313, 242);
            this.pc19.Name = "pc19";
            this.pc19.Size = new System.Drawing.Size(125, 80);
            this.pc19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc19.TabIndex = 22;
            this.pc19.TabStop = false;
            this.pc19.Click += new System.EventHandler(this.pc19_Click);
            // 
            // pc18
            // 
            this.pc18.BackColor = System.Drawing.Color.Transparent;
            this.pc18.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc18.Location = new System.Drawing.Point(161, 242);
            this.pc18.Name = "pc18";
            this.pc18.Size = new System.Drawing.Size(125, 80);
            this.pc18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc18.TabIndex = 21;
            this.pc18.TabStop = false;
            this.pc18.Click += new System.EventHandler(this.pc18_Click);
            // 
            // pc17
            // 
            this.pc17.BackColor = System.Drawing.Color.Transparent;
            this.pc17.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc17.Location = new System.Drawing.Point(12, 242);
            this.pc17.Name = "pc17";
            this.pc17.Size = new System.Drawing.Size(125, 80);
            this.pc17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc17.TabIndex = 20;
            this.pc17.TabStop = false;
            this.pc17.Click += new System.EventHandler(this.pc17_Click);
            // 
            // pc56
            // 
            this.pc56.BackColor = System.Drawing.Color.Transparent;
            this.pc56.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc56.Location = new System.Drawing.Point(1065, 702);
            this.pc56.Name = "pc56";
            this.pc56.Size = new System.Drawing.Size(125, 80);
            this.pc56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc56.TabIndex = 59;
            this.pc56.TabStop = false;
            // 
            // pc55
            // 
            this.pc55.BackColor = System.Drawing.Color.Transparent;
            this.pc55.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc55.Location = new System.Drawing.Point(917, 702);
            this.pc55.Name = "pc55";
            this.pc55.Size = new System.Drawing.Size(125, 80);
            this.pc55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc55.TabIndex = 58;
            this.pc55.TabStop = false;
            // 
            // pc54
            // 
            this.pc54.BackColor = System.Drawing.Color.Transparent;
            this.pc54.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc54.Location = new System.Drawing.Point(765, 702);
            this.pc54.Name = "pc54";
            this.pc54.Size = new System.Drawing.Size(125, 80);
            this.pc54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc54.TabIndex = 57;
            this.pc54.TabStop = false;
            // 
            // pc53
            // 
            this.pc53.BackColor = System.Drawing.Color.Transparent;
            this.pc53.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc53.Location = new System.Drawing.Point(614, 702);
            this.pc53.Name = "pc53";
            this.pc53.Size = new System.Drawing.Size(125, 80);
            this.pc53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc53.TabIndex = 56;
            this.pc53.TabStop = false;
            // 
            // pc52
            // 
            this.pc52.BackColor = System.Drawing.Color.Transparent;
            this.pc52.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc52.Location = new System.Drawing.Point(462, 702);
            this.pc52.Name = "pc52";
            this.pc52.Size = new System.Drawing.Size(125, 80);
            this.pc52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc52.TabIndex = 55;
            this.pc52.TabStop = false;
            // 
            // pc51
            // 
            this.pc51.BackColor = System.Drawing.Color.Transparent;
            this.pc51.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc51.Location = new System.Drawing.Point(313, 702);
            this.pc51.Name = "pc51";
            this.pc51.Size = new System.Drawing.Size(125, 80);
            this.pc51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc51.TabIndex = 54;
            this.pc51.TabStop = false;
            // 
            // pc50
            // 
            this.pc50.BackColor = System.Drawing.Color.Transparent;
            this.pc50.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc50.Location = new System.Drawing.Point(161, 702);
            this.pc50.Name = "pc50";
            this.pc50.Size = new System.Drawing.Size(125, 80);
            this.pc50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc50.TabIndex = 53;
            this.pc50.TabStop = false;
            // 
            // pc49
            // 
            this.pc49.BackColor = System.Drawing.Color.Transparent;
            this.pc49.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc49.Location = new System.Drawing.Point(12, 702);
            this.pc49.Name = "pc49";
            this.pc49.Size = new System.Drawing.Size(125, 80);
            this.pc49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc49.TabIndex = 52;
            this.pc49.TabStop = false;
            // 
            // pc48
            // 
            this.pc48.BackColor = System.Drawing.Color.Transparent;
            this.pc48.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc48.Location = new System.Drawing.Point(1065, 590);
            this.pc48.Name = "pc48";
            this.pc48.Size = new System.Drawing.Size(125, 80);
            this.pc48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc48.TabIndex = 51;
            this.pc48.TabStop = false;
            // 
            // pc47
            // 
            this.pc47.BackColor = System.Drawing.Color.Transparent;
            this.pc47.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc47.Location = new System.Drawing.Point(917, 589);
            this.pc47.Name = "pc47";
            this.pc47.Size = new System.Drawing.Size(125, 80);
            this.pc47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc47.TabIndex = 50;
            this.pc47.TabStop = false;
            // 
            // pc46
            // 
            this.pc46.BackColor = System.Drawing.Color.Transparent;
            this.pc46.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc46.Location = new System.Drawing.Point(765, 589);
            this.pc46.Name = "pc46";
            this.pc46.Size = new System.Drawing.Size(125, 80);
            this.pc46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc46.TabIndex = 49;
            this.pc46.TabStop = false;
            // 
            // pc45
            // 
            this.pc45.BackColor = System.Drawing.Color.Transparent;
            this.pc45.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc45.Location = new System.Drawing.Point(614, 590);
            this.pc45.Name = "pc45";
            this.pc45.Size = new System.Drawing.Size(125, 80);
            this.pc45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc45.TabIndex = 48;
            this.pc45.TabStop = false;
            // 
            // pc44
            // 
            this.pc44.BackColor = System.Drawing.Color.Transparent;
            this.pc44.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc44.Location = new System.Drawing.Point(462, 591);
            this.pc44.Name = "pc44";
            this.pc44.Size = new System.Drawing.Size(125, 80);
            this.pc44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc44.TabIndex = 47;
            this.pc44.TabStop = false;
            // 
            // pc43
            // 
            this.pc43.BackColor = System.Drawing.Color.Transparent;
            this.pc43.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc43.Location = new System.Drawing.Point(313, 589);
            this.pc43.Name = "pc43";
            this.pc43.Size = new System.Drawing.Size(125, 80);
            this.pc43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc43.TabIndex = 46;
            this.pc43.TabStop = false;
            // 
            // pc42
            // 
            this.pc42.BackColor = System.Drawing.Color.Transparent;
            this.pc42.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc42.Location = new System.Drawing.Point(161, 589);
            this.pc42.Name = "pc42";
            this.pc42.Size = new System.Drawing.Size(125, 80);
            this.pc42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc42.TabIndex = 45;
            this.pc42.TabStop = false;
            // 
            // pc41
            // 
            this.pc41.BackColor = System.Drawing.Color.Transparent;
            this.pc41.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc41.Location = new System.Drawing.Point(12, 589);
            this.pc41.Name = "pc41";
            this.pc41.Size = new System.Drawing.Size(125, 80);
            this.pc41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc41.TabIndex = 44;
            this.pc41.TabStop = false;
            // 
            // pc40
            // 
            this.pc40.BackColor = System.Drawing.Color.Transparent;
            this.pc40.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc40.Location = new System.Drawing.Point(1065, 472);
            this.pc40.Name = "pc40";
            this.pc40.Size = new System.Drawing.Size(125, 80);
            this.pc40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc40.TabIndex = 43;
            this.pc40.TabStop = false;
            this.pc40.Click += new System.EventHandler(this.pc40_Click);
            // 
            // pc39
            // 
            this.pc39.BackColor = System.Drawing.Color.Transparent;
            this.pc39.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc39.Location = new System.Drawing.Point(917, 472);
            this.pc39.Name = "pc39";
            this.pc39.Size = new System.Drawing.Size(125, 80);
            this.pc39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc39.TabIndex = 42;
            this.pc39.TabStop = false;
            this.pc39.Click += new System.EventHandler(this.pc39_Click);
            // 
            // pc38
            // 
            this.pc38.BackColor = System.Drawing.Color.Transparent;
            this.pc38.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc38.Location = new System.Drawing.Point(765, 472);
            this.pc38.Name = "pc38";
            this.pc38.Size = new System.Drawing.Size(125, 80);
            this.pc38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc38.TabIndex = 41;
            this.pc38.TabStop = false;
            this.pc38.Click += new System.EventHandler(this.pc38_Click);
            // 
            // pc37
            // 
            this.pc37.BackColor = System.Drawing.Color.Transparent;
            this.pc37.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc37.Location = new System.Drawing.Point(614, 472);
            this.pc37.Name = "pc37";
            this.pc37.Size = new System.Drawing.Size(125, 80);
            this.pc37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc37.TabIndex = 40;
            this.pc37.TabStop = false;
            this.pc37.Click += new System.EventHandler(this.pc37_Click);
            // 
            // pc36
            // 
            this.pc36.BackColor = System.Drawing.Color.Transparent;
            this.pc36.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc36.Location = new System.Drawing.Point(462, 472);
            this.pc36.Name = "pc36";
            this.pc36.Size = new System.Drawing.Size(125, 80);
            this.pc36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc36.TabIndex = 39;
            this.pc36.TabStop = false;
            this.pc36.Click += new System.EventHandler(this.pc36_Click);
            // 
            // pc35
            // 
            this.pc35.BackColor = System.Drawing.Color.Transparent;
            this.pc35.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc35.Location = new System.Drawing.Point(313, 472);
            this.pc35.Name = "pc35";
            this.pc35.Size = new System.Drawing.Size(125, 80);
            this.pc35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc35.TabIndex = 38;
            this.pc35.TabStop = false;
            this.pc35.Click += new System.EventHandler(this.pc35_Click);
            // 
            // pc34
            // 
            this.pc34.BackColor = System.Drawing.Color.Transparent;
            this.pc34.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc34.Location = new System.Drawing.Point(161, 472);
            this.pc34.Name = "pc34";
            this.pc34.Size = new System.Drawing.Size(125, 80);
            this.pc34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc34.TabIndex = 37;
            this.pc34.TabStop = false;
            this.pc34.Click += new System.EventHandler(this.pc34_Click);
            // 
            // pc33
            // 
            this.pc33.BackColor = System.Drawing.Color.Transparent;
            this.pc33.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc33.Location = new System.Drawing.Point(12, 472);
            this.pc33.Name = "pc33";
            this.pc33.Size = new System.Drawing.Size(125, 80);
            this.pc33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc33.TabIndex = 36;
            this.pc33.TabStop = false;
            this.pc33.Click += new System.EventHandler(this.pc33_Click);
            // 
            // RevisionPC
            // 
            this.RevisionPC.Interval = 500;
            this.RevisionPC.Tick += new System.EventHandler(this.RevisionPC_Tick);
            // 
            // pc1
            // 
            this.pc1.BackColor = System.Drawing.Color.Transparent;
            this.pc1.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc1.Location = new System.Drawing.Point(12, 12);
            this.pc1.Name = "pc1";
            this.pc1.Size = new System.Drawing.Size(125, 80);
            this.pc1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc1.TabIndex = 60;
            this.pc1.TabStop = false;
            this.pc1.Click += new System.EventHandler(this.pc1_Click);
            // 
            // pc2
            // 
            this.pc2.BackColor = System.Drawing.Color.Transparent;
            this.pc2.Image = global::Centro_de_cumputo.Properties.Resources.opt3020libre;
            this.pc2.Location = new System.Drawing.Point(161, 12);
            this.pc2.Name = "pc2";
            this.pc2.Size = new System.Drawing.Size(125, 80);
            this.pc2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc2.TabIndex = 61;
            this.pc2.TabStop = false;
            this.pc2.Click += new System.EventHandler(this.pc2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(313, 843);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 62;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(400, 843);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 25);
            this.label1.TabIndex = 63;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // lblNombre1
            // 
            this.lblNombre1.AutoSize = true;
            this.lblNombre1.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre1.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre1.Location = new System.Drawing.Point(12, 95);
            this.lblNombre1.Name = "lblNombre1";
            this.lblNombre1.Size = new System.Drawing.Size(118, 25);
            this.lblNombre1.TabIndex = 64;
            this.lblNombre1.Text = "Maquina 1";
            this.lblNombre1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre2
            // 
            this.lblNombre2.AutoSize = true;
            this.lblNombre2.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre2.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre2.Location = new System.Drawing.Point(156, 95);
            this.lblNombre2.Name = "lblNombre2";
            this.lblNombre2.Size = new System.Drawing.Size(118, 25);
            this.lblNombre2.TabIndex = 65;
            this.lblNombre2.Text = "Maquina 2";
            this.lblNombre2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre3
            // 
            this.lblNombre3.AutoSize = true;
            this.lblNombre3.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre3.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre3.Location = new System.Drawing.Point(308, 95);
            this.lblNombre3.Name = "lblNombre3";
            this.lblNombre3.Size = new System.Drawing.Size(118, 25);
            this.lblNombre3.TabIndex = 66;
            this.lblNombre3.Text = "Maquina 3";
            this.lblNombre3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre6
            // 
            this.lblNombre6.AutoSize = true;
            this.lblNombre6.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre6.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre6.Location = new System.Drawing.Point(763, 96);
            this.lblNombre6.Name = "lblNombre6";
            this.lblNombre6.Size = new System.Drawing.Size(118, 25);
            this.lblNombre6.TabIndex = 69;
            this.lblNombre6.Text = "Maquina 6";
            this.lblNombre6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre5
            // 
            this.lblNombre5.AutoSize = true;
            this.lblNombre5.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre5.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre5.Location = new System.Drawing.Point(611, 96);
            this.lblNombre5.Name = "lblNombre5";
            this.lblNombre5.Size = new System.Drawing.Size(118, 25);
            this.lblNombre5.TabIndex = 68;
            this.lblNombre5.Text = "Maquina 5";
            this.lblNombre5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre4
            // 
            this.lblNombre4.AutoSize = true;
            this.lblNombre4.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre4.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre4.Location = new System.Drawing.Point(457, 96);
            this.lblNombre4.Name = "lblNombre4";
            this.lblNombre4.Size = new System.Drawing.Size(118, 25);
            this.lblNombre4.TabIndex = 67;
            this.lblNombre4.Text = "Maquina 4";
            this.lblNombre4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre8
            // 
            this.lblNombre8.AutoSize = true;
            this.lblNombre8.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre8.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre8.Location = new System.Drawing.Point(1064, 95);
            this.lblNombre8.Name = "lblNombre8";
            this.lblNombre8.Size = new System.Drawing.Size(118, 25);
            this.lblNombre8.TabIndex = 71;
            this.lblNombre8.Text = "Maquina 8";
            this.lblNombre8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre7
            // 
            this.lblNombre7.AutoSize = true;
            this.lblNombre7.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre7.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre7.Location = new System.Drawing.Point(912, 95);
            this.lblNombre7.Name = "lblNombre7";
            this.lblNombre7.Size = new System.Drawing.Size(118, 25);
            this.lblNombre7.TabIndex = 70;
            this.lblNombre7.Text = "Maquina 7";
            this.lblNombre7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre16
            // 
            this.lblNombre16.AutoSize = true;
            this.lblNombre16.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre16.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre16.Location = new System.Drawing.Point(1064, 211);
            this.lblNombre16.Name = "lblNombre16";
            this.lblNombre16.Size = new System.Drawing.Size(130, 25);
            this.lblNombre16.TabIndex = 79;
            this.lblNombre16.Text = "Maquina 16";
            this.lblNombre16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre15
            // 
            this.lblNombre15.AutoSize = true;
            this.lblNombre15.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre15.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre15.Location = new System.Drawing.Point(912, 211);
            this.lblNombre15.Name = "lblNombre15";
            this.lblNombre15.Size = new System.Drawing.Size(130, 25);
            this.lblNombre15.TabIndex = 78;
            this.lblNombre15.Text = "Maquina 15";
            this.lblNombre15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre14
            // 
            this.lblNombre14.AutoSize = true;
            this.lblNombre14.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre14.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre14.Location = new System.Drawing.Point(763, 212);
            this.lblNombre14.Name = "lblNombre14";
            this.lblNombre14.Size = new System.Drawing.Size(130, 25);
            this.lblNombre14.TabIndex = 77;
            this.lblNombre14.Text = "Maquina 14";
            this.lblNombre14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre13
            // 
            this.lblNombre13.AutoSize = true;
            this.lblNombre13.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre13.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre13.Location = new System.Drawing.Point(611, 212);
            this.lblNombre13.Name = "lblNombre13";
            this.lblNombre13.Size = new System.Drawing.Size(130, 25);
            this.lblNombre13.TabIndex = 76;
            this.lblNombre13.Text = "Maquina 13";
            this.lblNombre13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre12
            // 
            this.lblNombre12.AutoSize = true;
            this.lblNombre12.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre12.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre12.Location = new System.Drawing.Point(457, 212);
            this.lblNombre12.Name = "lblNombre12";
            this.lblNombre12.Size = new System.Drawing.Size(130, 25);
            this.lblNombre12.TabIndex = 75;
            this.lblNombre12.Text = "Maquina 12";
            this.lblNombre12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre11
            // 
            this.lblNombre11.AutoSize = true;
            this.lblNombre11.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre11.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre11.Location = new System.Drawing.Point(308, 211);
            this.lblNombre11.Name = "lblNombre11";
            this.lblNombre11.Size = new System.Drawing.Size(130, 25);
            this.lblNombre11.TabIndex = 74;
            this.lblNombre11.Text = "Maquina 11";
            this.lblNombre11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre10
            // 
            this.lblNombre10.AutoSize = true;
            this.lblNombre10.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre10.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre10.Location = new System.Drawing.Point(156, 211);
            this.lblNombre10.Name = "lblNombre10";
            this.lblNombre10.Size = new System.Drawing.Size(130, 25);
            this.lblNombre10.TabIndex = 73;
            this.lblNombre10.Text = "Maquina 10";
            this.lblNombre10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre9
            // 
            this.lblNombre9.AutoSize = true;
            this.lblNombre9.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre9.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre9.Location = new System.Drawing.Point(12, 211);
            this.lblNombre9.Name = "lblNombre9";
            this.lblNombre9.Size = new System.Drawing.Size(118, 25);
            this.lblNombre9.TabIndex = 72;
            this.lblNombre9.Text = "Maquina 9";
            this.lblNombre9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre24
            // 
            this.lblNombre24.AutoSize = true;
            this.lblNombre24.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre24.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre24.Location = new System.Drawing.Point(1064, 325);
            this.lblNombre24.Name = "lblNombre24";
            this.lblNombre24.Size = new System.Drawing.Size(130, 25);
            this.lblNombre24.TabIndex = 87;
            this.lblNombre24.Text = "Maquina 24";
            this.lblNombre24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre23
            // 
            this.lblNombre23.AutoSize = true;
            this.lblNombre23.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre23.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre23.Location = new System.Drawing.Point(912, 325);
            this.lblNombre23.Name = "lblNombre23";
            this.lblNombre23.Size = new System.Drawing.Size(130, 25);
            this.lblNombre23.TabIndex = 86;
            this.lblNombre23.Text = "Maquina 23";
            this.lblNombre23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre22
            // 
            this.lblNombre22.AutoSize = true;
            this.lblNombre22.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre22.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre22.Location = new System.Drawing.Point(763, 326);
            this.lblNombre22.Name = "lblNombre22";
            this.lblNombre22.Size = new System.Drawing.Size(130, 25);
            this.lblNombre22.TabIndex = 85;
            this.lblNombre22.Text = "Maquina 22";
            this.lblNombre22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre21
            // 
            this.lblNombre21.AutoSize = true;
            this.lblNombre21.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre21.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre21.Location = new System.Drawing.Point(611, 326);
            this.lblNombre21.Name = "lblNombre21";
            this.lblNombre21.Size = new System.Drawing.Size(130, 25);
            this.lblNombre21.TabIndex = 84;
            this.lblNombre21.Text = "Maquina 21";
            this.lblNombre21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre20
            // 
            this.lblNombre20.AutoSize = true;
            this.lblNombre20.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre20.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre20.Location = new System.Drawing.Point(457, 326);
            this.lblNombre20.Name = "lblNombre20";
            this.lblNombre20.Size = new System.Drawing.Size(130, 25);
            this.lblNombre20.TabIndex = 83;
            this.lblNombre20.Text = "Maquina 20";
            this.lblNombre20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre19
            // 
            this.lblNombre19.AutoSize = true;
            this.lblNombre19.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre19.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre19.Location = new System.Drawing.Point(308, 325);
            this.lblNombre19.Name = "lblNombre19";
            this.lblNombre19.Size = new System.Drawing.Size(130, 25);
            this.lblNombre19.TabIndex = 82;
            this.lblNombre19.Text = "Maquina 19";
            this.lblNombre19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre18
            // 
            this.lblNombre18.AutoSize = true;
            this.lblNombre18.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre18.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre18.Location = new System.Drawing.Point(156, 325);
            this.lblNombre18.Name = "lblNombre18";
            this.lblNombre18.Size = new System.Drawing.Size(130, 25);
            this.lblNombre18.TabIndex = 81;
            this.lblNombre18.Text = "Maquina 18";
            this.lblNombre18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombre17
            // 
            this.lblNombre17.AutoSize = true;
            this.lblNombre17.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre17.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre17.Location = new System.Drawing.Point(12, 325);
            this.lblNombre17.Name = "lblNombre17";
            this.lblNombre17.Size = new System.Drawing.Size(130, 25);
            this.lblNombre17.TabIndex = 80;
            this.lblNombre17.Text = "Maquina 17";
            this.lblNombre17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(1064, 444);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(130, 25);
            this.label25.TabIndex = 95;
            this.label25.Text = "Maquina 32";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(912, 444);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(130, 25);
            this.label26.TabIndex = 94;
            this.label26.Text = "Maquina 31";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(763, 445);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(130, 25);
            this.label27.TabIndex = 93;
            this.label27.Text = "Maquina 30";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(611, 445);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(130, 25);
            this.label28.TabIndex = 92;
            this.label28.Text = "Maquina 29";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(457, 445);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(130, 25);
            this.label29.TabIndex = 91;
            this.label29.Text = "Maquina 28";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(308, 444);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(130, 25);
            this.label30.TabIndex = 90;
            this.label30.Text = "Maquina 27";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(156, 444);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(130, 25);
            this.label31.TabIndex = 89;
            this.label31.Text = "Maquina 26";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(12, 444);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(130, 25);
            this.label32.TabIndex = 88;
            this.label32.Text = "Maquina 25";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(1064, 555);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(130, 25);
            this.label33.TabIndex = 103;
            this.label33.Text = "Maquina 40";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(912, 555);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(130, 25);
            this.label34.TabIndex = 102;
            this.label34.Text = "Maquina 39";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(763, 556);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(130, 25);
            this.label35.TabIndex = 101;
            this.label35.Text = "Maquina 38";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(611, 556);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(130, 25);
            this.label36.TabIndex = 100;
            this.label36.Text = "Maquina 37";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(457, 556);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(130, 25);
            this.label37.TabIndex = 99;
            this.label37.Text = "Maquina 36";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(308, 555);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(130, 25);
            this.label38.TabIndex = 98;
            this.label38.Text = "Maquina 35";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(156, 555);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(130, 25);
            this.label39.TabIndex = 97;
            this.label39.Text = "Maquina 34";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(12, 555);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(130, 25);
            this.label40.TabIndex = 96;
            this.label40.Text = "Maquina 33";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(1064, 672);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(130, 25);
            this.label41.TabIndex = 111;
            this.label41.Text = "Maquina 48";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(912, 672);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(130, 25);
            this.label42.TabIndex = 110;
            this.label42.Text = "Maquina 47";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(763, 673);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(130, 25);
            this.label43.TabIndex = 109;
            this.label43.Text = "Maquina 46";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(611, 673);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(130, 25);
            this.label44.TabIndex = 108;
            this.label44.Text = "Maquina 45";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(457, 673);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(130, 25);
            this.label45.TabIndex = 107;
            this.label45.Text = "Maquina 44";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(308, 672);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(130, 25);
            this.label46.TabIndex = 106;
            this.label46.Text = "Maquina 43";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Transparent;
            this.label47.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(156, 672);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(130, 25);
            this.label47.TabIndex = 105;
            this.label47.Text = "Maquina 42";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(12, 672);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(130, 25);
            this.label48.TabIndex = 104;
            this.label48.Text = "Maquina 41";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Transparent;
            this.label49.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(1064, 785);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(130, 25);
            this.label49.TabIndex = 119;
            this.label49.Text = "Maquina 56";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(912, 785);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(130, 25);
            this.label50.TabIndex = 118;
            this.label50.Text = "Maquina 55";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(763, 786);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(130, 25);
            this.label51.TabIndex = 117;
            this.label51.Text = "Maquina 54";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.label52.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(611, 786);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(130, 25);
            this.label52.TabIndex = 116;
            this.label52.Text = "Maquina 53";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Transparent;
            this.label53.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(457, 786);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(130, 25);
            this.label53.TabIndex = 115;
            this.label53.Text = "Maquina 52";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Transparent;
            this.label54.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(308, 785);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(130, 25);
            this.label54.TabIndex = 114;
            this.label54.Text = "Maquina 51";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(156, 785);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(130, 25);
            this.label55.TabIndex = 113;
            this.label55.Text = "Maquina 50";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Transparent;
            this.label56.Font = new System.Drawing.Font("Rockwell", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(12, 785);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(130, 25);
            this.label56.TabIndex = 112;
            this.label56.Text = "Maquina 49";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(17, 843);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(92, 43);
            this.btnSalir.TabIndex = 120;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.BackColor = System.Drawing.Color.Transparent;
            this.lblMensaje.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensaje.Location = new System.Drawing.Point(610, 843);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(0, 39);
            this.lblMensaje.TabIndex = 11;
            this.lblMensaje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMensaje.Visible = false;
            // 
            // PaginaUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.BackgroundImage = global::Centro_de_cumputo.Properties.Resources.fondo2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.lblNombre24);
            this.Controls.Add(this.lblNombre23);
            this.Controls.Add(this.lblNombre22);
            this.Controls.Add(this.lblNombre21);
            this.Controls.Add(this.lblNombre20);
            this.Controls.Add(this.lblNombre19);
            this.Controls.Add(this.lblNombre18);
            this.Controls.Add(this.lblNombre17);
            this.Controls.Add(this.lblNombre16);
            this.Controls.Add(this.lblNombre15);
            this.Controls.Add(this.lblNombre14);
            this.Controls.Add(this.lblNombre13);
            this.Controls.Add(this.lblNombre12);
            this.Controls.Add(this.lblNombre11);
            this.Controls.Add(this.lblNombre10);
            this.Controls.Add(this.lblNombre9);
            this.Controls.Add(this.lblNombre8);
            this.Controls.Add(this.lblNombre7);
            this.Controls.Add(this.lblNombre6);
            this.Controls.Add(this.lblNombre5);
            this.Controls.Add(this.lblNombre4);
            this.Controls.Add(this.lblNombre3);
            this.Controls.Add(this.lblNombre2);
            this.Controls.Add(this.lblNombre1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pc2);
            this.Controls.Add(this.pc1);
            this.Controls.Add(this.panelCodigo);
            this.Controls.Add(this.pc55);
            this.Controls.Add(this.pc54);
            this.Controls.Add(this.pc56);
            this.Controls.Add(this.pc53);
            this.Controls.Add(this.pc52);
            this.Controls.Add(this.pc51);
            this.Controls.Add(this.pc50);
            this.Controls.Add(this.pc49);
            this.Controls.Add(this.pc48);
            this.Controls.Add(this.pc47);
            this.Controls.Add(this.pc46);
            this.Controls.Add(this.pc45);
            this.Controls.Add(this.pc44);
            this.Controls.Add(this.pc43);
            this.Controls.Add(this.pc42);
            this.Controls.Add(this.pc41);
            this.Controls.Add(this.pc40);
            this.Controls.Add(this.pc39);
            this.Controls.Add(this.pc38);
            this.Controls.Add(this.pc37);
            this.Controls.Add(this.pc36);
            this.Controls.Add(this.pc35);
            this.Controls.Add(this.pc34);
            this.Controls.Add(this.pc33);
            this.Controls.Add(this.pc32);
            this.Controls.Add(this.pc31);
            this.Controls.Add(this.pc30);
            this.Controls.Add(this.pc29);
            this.Controls.Add(this.pc28);
            this.Controls.Add(this.pc27);
            this.Controls.Add(this.pc26);
            this.Controls.Add(this.pc25);
            this.Controls.Add(this.pc24);
            this.Controls.Add(this.pc23);
            this.Controls.Add(this.pc22);
            this.Controls.Add(this.pc21);
            this.Controls.Add(this.pc20);
            this.Controls.Add(this.pc19);
            this.Controls.Add(this.pc18);
            this.Controls.Add(this.pc17);
            this.Controls.Add(this.pc16);
            this.Controls.Add(this.pc15);
            this.Controls.Add(this.pc14);
            this.Controls.Add(this.pc13);
            this.Controls.Add(this.pc12);
            this.Controls.Add(this.pc11);
            this.Controls.Add(this.pc10);
            this.Controls.Add(this.pc9);
            this.Controls.Add(this.pc8);
            this.Controls.Add(this.pc7);
            this.Controls.Add(this.pc6);
            this.Controls.Add(this.pc5);
            this.Controls.Add(this.pc4);
            this.Controls.Add(this.pc3);
            this.Controls.Add(this.pcInactiva);
            this.Controls.Add(this.pcActiva);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PaginaUsuario";
            this.Text = "PaginaUsuario";
            this.Load += new System.EventHandler(this.PaginaUsuario_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PaginaUsuario_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PaginaUsuario_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PaginaUsuario_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.pcActiva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcInactiva)).EndInit();
            this.panelCodigo.ResumeLayout(false);
            this.panelCodigo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pc4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pcActiva;
        private System.Windows.Forms.PictureBox pcInactiva;
        private System.Windows.Forms.Panel panelCodigo;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Label lblCerrar;
        private System.Windows.Forms.Button btnDevolver;
        private System.Windows.Forms.PictureBox pc4;
        private System.Windows.Forms.PictureBox pc3;
        private System.Windows.Forms.PictureBox pc8;
        private System.Windows.Forms.PictureBox pc7;
        private System.Windows.Forms.PictureBox pc6;
        private System.Windows.Forms.PictureBox pc5;
        private System.Windows.Forms.PictureBox pc16;
        private System.Windows.Forms.PictureBox pc15;
        private System.Windows.Forms.PictureBox pc14;
        private System.Windows.Forms.PictureBox pc13;
        private System.Windows.Forms.PictureBox pc12;
        private System.Windows.Forms.PictureBox pc11;
        private System.Windows.Forms.PictureBox pc10;
        private System.Windows.Forms.PictureBox pc9;
        private System.Windows.Forms.PictureBox pc32;
        private System.Windows.Forms.PictureBox pc31;
        private System.Windows.Forms.PictureBox pc30;
        private System.Windows.Forms.PictureBox pc29;
        private System.Windows.Forms.PictureBox pc28;
        private System.Windows.Forms.PictureBox pc27;
        private System.Windows.Forms.PictureBox pc26;
        private System.Windows.Forms.PictureBox pc25;
        private System.Windows.Forms.PictureBox pc24;
        private System.Windows.Forms.PictureBox pc23;
        private System.Windows.Forms.PictureBox pc22;
        private System.Windows.Forms.PictureBox pc21;
        private System.Windows.Forms.PictureBox pc20;
        private System.Windows.Forms.PictureBox pc19;
        private System.Windows.Forms.PictureBox pc18;
        private System.Windows.Forms.PictureBox pc17;
        private System.Windows.Forms.PictureBox pc56;
        private System.Windows.Forms.PictureBox pc55;
        private System.Windows.Forms.PictureBox pc54;
        private System.Windows.Forms.PictureBox pc53;
        private System.Windows.Forms.PictureBox pc52;
        private System.Windows.Forms.PictureBox pc51;
        private System.Windows.Forms.PictureBox pc50;
        private System.Windows.Forms.PictureBox pc49;
        private System.Windows.Forms.PictureBox pc48;
        private System.Windows.Forms.PictureBox pc47;
        private System.Windows.Forms.PictureBox pc46;
        private System.Windows.Forms.PictureBox pc45;
        private System.Windows.Forms.PictureBox pc44;
        private System.Windows.Forms.PictureBox pc43;
        private System.Windows.Forms.PictureBox pc42;
        private System.Windows.Forms.PictureBox pc41;
        private System.Windows.Forms.PictureBox pc40;
        private System.Windows.Forms.PictureBox pc38;
        private System.Windows.Forms.PictureBox pc37;
        private System.Windows.Forms.PictureBox pc36;
        private System.Windows.Forms.PictureBox pc35;
        private System.Windows.Forms.PictureBox pc34;
        private System.Windows.Forms.PictureBox pc33;
        private System.Windows.Forms.PictureBox pc39;
        private System.Windows.Forms.Timer RevisionPC;
        private System.Windows.Forms.PictureBox pc1;
        private System.Windows.Forms.PictureBox pc2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTexto2;
        private System.Windows.Forms.Label lblNombre1;
        private System.Windows.Forms.Label lblNombre2;
        private System.Windows.Forms.Label lblNombre3;
        private System.Windows.Forms.Label lblNombre6;
        private System.Windows.Forms.Label lblNombre5;
        private System.Windows.Forms.Label lblNombre4;
        private System.Windows.Forms.Label lblNombre8;
        private System.Windows.Forms.Label lblNombre7;
        private System.Windows.Forms.Label lblNombre16;
        private System.Windows.Forms.Label lblNombre15;
        private System.Windows.Forms.Label lblNombre14;
        private System.Windows.Forms.Label lblNombre13;
        private System.Windows.Forms.Label lblNombre12;
        private System.Windows.Forms.Label lblNombre11;
        private System.Windows.Forms.Label lblNombre10;
        private System.Windows.Forms.Label lblNombre9;
        private System.Windows.Forms.Label lblNombre24;
        private System.Windows.Forms.Label lblNombre23;
        private System.Windows.Forms.Label lblNombre22;
        private System.Windows.Forms.Label lblNombre21;
        private System.Windows.Forms.Label lblNombre20;
        private System.Windows.Forms.Label lblNombre19;
        private System.Windows.Forms.Label lblNombre18;
        private System.Windows.Forms.Label lblNombre17;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.ListBox listaCodigo;
        private System.Windows.Forms.Label lblTexto1;
        private System.Windows.Forms.Label lblTexto3;
        private System.Windows.Forms.Button btnQuitar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label lblMensaje;
    }
}