﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Centro_de_cumputo
{
    public partial class PaginaUsuario : Form
    {
        //MOVER FORMA
        int TogMove;
        int MvalX;
        int MvalY;


        int contadorCodigosLista;




        string Codigo;
        string NumeroPC;
        string NumeroPCFinal;
        string Fecha;
        bool PruebaDevolver;
        int algo;
        string Cadena;
        string CodigoViejo;
        int contadorTiempo;
        string HoraFechaSALIDA;
        byte ContadorMaquinas;
        string[] Maquina = new string[57];
        PictureBox[] pc = new PictureBox[21];

        public PaginaUsuario()
        {
            InitializeComponent();
        }

        private void PosicionVentana()
        {
            txtCodigo.Text = "";
            panelCodigo.Left = this.Width / 2 - (panelCodigo.Width / 2);
            panelCodigo.Top = this.Height / 2 - (panelCodigo.Height / 2);
            panelCodigo.Visible = true;
            txtCodigo.Focus();
        }
private void IngresoCodigo(int[] VectorCodigos)
{
    if (VectorCodigos.Length > 0)
    {
        //VARIABLES
        int contadorCiclo = 0;
        int contadorCantidadMaquinas = 0;
        int[] VectorLugares = new int[57];
        string[] VectorMaquina = new string[57];
        byte DisponibilidadEnVerdadero = 1;

        //BUSCA ESA CANTIDAD DE MAQUINAS DISPONIBLES
        SqlConnection conexion2 = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
        conexion2.Open();
        string cadena2 = "select Maquina, Disponibilidad from MaquinasD where Disponibilidad=" + 1;
        SqlCommand comando2 = new SqlCommand(cadena2, conexion2);
        SqlDataReader registros2 = comando2.ExecuteReader();
        while (registros2.Read())
        {
            VectorMaquina[contadorCiclo] = registros2["Maquina"].ToString();
            VectorLugares[contadorCiclo] = Convert.ToInt32(registros2["Disponibilidad"]);
            if (VectorLugares[contadorCiclo] > 0)
            {
                contadorCantidadMaquinas++;
            }

            contadorCiclo++;
            if (contadorCiclo > 56)
            {
                contadorCiclo = 0;
            }
        }
        conexion2.Close();
        //MessageBox.Show("Hay " + contadorCantidadMaquinas + " maquinas disponibles, y el vector codigos es de " + VectorCodigos.Length);
        if (contadorCantidadMaquinas < VectorCodigos.Length)
        {
            MessageBox.Show("No hay tantas maquinas disponibles :(");
        }
        else//SI CONTADOR_CANTIDAD_MAQUINAS ES MAYOR A 0
        {

            if (PruebaDevolver == false)
            {
                //VARIABLES
                string lineatexto = "";
                char letra = Convert.ToChar("a");
                int conversionNumero = 0;
                string[] BusquedaMaquina = new string[9];
                int[] conversionNumero2 = new int[57];
                bool ok = false;
                int temp = 0;
                int temp2 = 0;



                //SEPARA EL NUMERO DEL TEXTO Maquina DE LA BASE DE DATOS
                for (contadorCiclo = 0; contadorCiclo < contadorCantidadMaquinas; contadorCiclo++)
                {
                    lineatexto = VectorMaquina[contadorCiclo];
                    string[] arreglollamadas = lineatexto.Split(letra);

                    conversionNumero2[contadorCiclo] = Convert.ToInt32(arreglollamadas[2]);
                }

                //VERIFICACION DE LUGARES
                for (contadorCiclo = 0; contadorCiclo < VectorCodigos.Length; contadorCiclo++)
                {
                    if (contadorCiclo == VectorCodigos.Length - 1)
                    {
                        temp = conversionNumero2[contadorCiclo];
                        temp2 = temp;
                    }
                    else
                    {
                        temp = conversionNumero2[contadorCiclo + 1];
                        temp2 = temp - 1;
                    }
                    if (conversionNumero2[contadorCiclo] == temp2)
                    {

                        ok = true;
                    }
                    else
                    {
                        ok = false;
                    }
                }

                //CUANDO OK ES VERDADERO
                if (ok == true)
                {
                    int contador3 = 0;
                    for (contador3 = 0; contador3 < VectorCodigos.Length; contador3++)
                    {
                        //VARIABLES INGRESO
                        DateTime Hoy = DateTime.Today;
                        string fecha_actual = Hoy.ToString("dd-MM-yyyy");
                        Fecha = fecha_actual + " " + DateTime.Now.ToShortTimeString();
                        string CodigoIngreso = listaCodigo.GetItemText(listaCodigo.Items[contador3]);
                        CodigoViejo = "0";

                        //VARIABLES
                        NumeroPCFinal = "Maquina" + conversionNumero2[contador3];
                        DisponibilidadEnVerdadero = 0;

                        SqlConnection Conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
                        Conexion.Open();

                        Cadena = "insert into ingresos(NoEstudiante,Nopc,HoraFechaEntrada,HoraFechaSalida) values ('" + CodigoIngreso + "', '" + NumeroPCFinal + "','" + Fecha + "','" + CodigoViejo + "'" + ")";
                        SqlCommand Comando = new SqlCommand(Cadena, Conexion);
                        Comando.ExecuteNonQuery();
                        Conexion.Close();

                        SqlConnection Conexion2 = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
                        Conexion2.Open();
                        string Cadena2 = "update MaquinasD set Disponibilidad=" + DisponibilidadEnVerdadero + " where Maquina='" + NumeroPCFinal + "'";
                        SqlCommand Comando2 = new SqlCommand(Cadena2, Conexion2);
                        int cant;
                        cant = Comando2.ExecuteNonQuery();
                        if (cant == 1)
                        {

                        }
                        else
                        {
                            MessageBox.Show("No existe una maquina con el código ingresado");
                        }
                        //CERRADO DE CONEXION
                        Conexion.Close();
                    }
                }
            }
            else
            {
                int contador3 = 0;
                bool ok2 = false;

                for (contador3 = 0; contador3 < VectorCodigos.Length; contador3++)
                {
                    SqlConnection conexion3 = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
                    conexion3.Open();
                    string cadena3 = "select NoEstudiante, Nopc from ingresos where NoEstudiante='" + VectorCodigos[contador3] + "' AND HoraFechaSalida='" + Convert.ToString(0) + "'";
                    SqlCommand comando3 = new SqlCommand(cadena3, conexion3);
                    SqlDataReader registros3 = comando3.ExecuteReader();
                    while (registros3.Read())
                    {
                        //MessageBox.Show("Se hace algo");
                        NumeroPCFinal = registros3["Nopc"].ToString();
                        ok2 = true;
                    }
                    conexion3.Close();

                    if (ok2 == true)
                    {
                        SqlConnection Conexion2 = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
                        Conexion2.Open();
                        string Cadena2 = "update MaquinasD set Disponibilidad=" + 1 + " where Maquina='" + NumeroPCFinal + "'";
                        SqlCommand Comando2 = new SqlCommand(Cadena2, Conexion2);
                        int cant;
                        cant = Comando2.ExecuteNonQuery();
                        if (cant == 1)
                        {

                        }
                        else
                        {
                            MessageBox.Show("No existe una maquina con el código ingresado");
                        }
                        //CERRADO DE CONEXION
                        Conexion2.Close();

                        //VARIABLES INGRESO
                        DateTime Hoy = DateTime.Today;
                        string fecha_actual = Hoy.ToString("dd-MM-yyyy");
                        Fecha = fecha_actual + " " + DateTime.Now.ToShortTimeString();
                        CodigoViejo = "0";

                        SqlConnection Conexion3 = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
                        Conexion3.Open();
                        string Cadena3 = "update Ingresos set HoraFechaSalida='" + Fecha + "' where NoEstudiante='" + VectorCodigos[contador3] + "' AND HoraFechaSalida='" + Convert.ToString(0) + "'";
                        SqlCommand Comando3 = new SqlCommand(Cadena3, Conexion3);
                        int cant2;
                        cant2 = Comando3.ExecuteNonQuery();
                        if (cant2 == 1)
                        {

                        }
                        else
                        {
                            MessageBox.Show("No existe una maquina con el código ingresado");
                        }
                        //CERRADO DE CONEXION
                        Conexion3.Close();
                    }
                    else
                    {
                        MessageBox.Show("no hay tal cosa");
                    }
                }
            }
        }
    }
    else//SI VECTORCODIGOS NO FUE MAYOR A 1
    {
        lblMensaje.Text = "No hay datos ingresados";
    }
    listaCodigo.Items.Clear();
    txtCodigo.Focus();
    lblTexto2.Text = Convert.ToString(listaCodigo.Items.Count);
    txtCodigo.Text = "";
    txtCodigo.Focus();
    lblMensaje.Visible = false;
    PruebaDevolver = false;
}

    
private void Revision()
{
    //VARIABLES
    int contador;
    //INICIALIZAR
    contador = 0;

    contadorTiempo++;
    label1.Text = Convert.ToString(contadorTiempo);
    SqlConnection conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
    conexion.Open();
    string cadena = "select Maquina, Disponibilidad from MaquinasD";
    SqlCommand comando = new SqlCommand(cadena, conexion);
    SqlDataReader registros = comando.ExecuteReader();
    while (registros.Read())
    {
        contador++;
        if (contador >= 57)
        {
            contador = 0;
        }
        Maquina[contador] = registros["Disponibilidad"].ToString();
    }
    conexion.Close();

    if (Convert.ToInt32(Maquina[1]) == 1)
    {
        pc1.Image = pcActiva.Image;
    }
    else
    {
        pc1.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[2]) == 1)
    {
        pc2.Image = pcActiva.Image;
    }
    else
    {
        pc2.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[3]) == 1)
    {
        pc3.Image = pcActiva.Image;
    }
    else
    {
        pc3.Image = pcInactiva.Image;
    }


    if (Convert.ToInt32(Maquina[4]) == 1)
    {
        pc4.Image = pcActiva.Image;
    }
    else
    {
        pc4.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[5]) == 1)
    {
        pc5.Image = pcActiva.Image;
    }
    else
    {
        pc5.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[6]) == 1)
    {
        pc6.Image = pcActiva.Image;
    }
    else
    {
        pc6.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[7]) == 1)
    {
        pc7.Image = pcActiva.Image;
    }
    else
    {
        pc7.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[8]) == 1)
    {
        pc8.Image = pcActiva.Image;
    }
    else
    {
        pc8.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[9]) == 1)
    {
        pc9.Image = pcActiva.Image;
    }
    else
    {
        pc9.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[10]) == 1)
    {
        pc10.Image = pcActiva.Image;
    }
    else
    {
        pc10.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[11]) == 1)
    {
        pc11.Image = pcActiva.Image;
    }
    else
    {
        pc11.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[12]) == 1)
    {
        pc12.Image = pcActiva.Image;
    }
    else
    {
        pc12.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[13]) == 1)
    {
        pc13.Image = pcActiva.Image;
    }
    else
    {
        pc13.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[14]) == 1)
    {
        pc14.Image = pcActiva.Image;
    }
    else
    {
        pc14.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[15]) == 1)
    {
        pc15.Image = pcActiva.Image;
    }
    else
    {
        pc15.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[16]) == 1)
    {
        pc16.Image = pcActiva.Image;
    }
    else
    {
        pc16.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[17]) == 1)
    {
        pc17.Image = pcActiva.Image;
    }
    else
    {
        pc17.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[18]) == 1)
    {
        pc18.Image = pcActiva.Image;
    }
    else
    {
        pc18.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[19]) == 1)
    {
        pc19.Image = pcActiva.Image;
    }
    else
    {
        pc19.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[20]) == 1)
    {
        pc20.Image = pcActiva.Image;
    }
    else
    {
        pc20.Image = pcInactiva.Image;
    }

    if (Convert.ToInt32(Maquina[21]) == 1)
    {
        pc21.Image = pcActiva.Image;
    }
    else
    {
        pc21.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[22]) == 1)
    {
        pc22.Image = pcActiva.Image;
    }
    else
    {
        pc22.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[23]) == 1)
    {
        pc23.Image = pcActiva.Image;
    }
    else
    {
        pc23.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[24]) == 1)
    {
        pc24.Image = pcActiva.Image;
    }
    else
    {
        pc24.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[25]) == 1)
    {
        pc25.Image = pcActiva.Image;
    }
    else
    {
        pc25.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[26]) == 1)
    {
        pc26.Image = pcActiva.Image;
    }
    else
    {
        pc26.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[27]) == 1)
    {
        pc27.Image = pcActiva.Image;
    }
    else
    {
        pc27.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[28]) == 1)
    {
        pc28.Image = pcActiva.Image;
    }
    else
    {
        pc28.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[29]) == 1)
    {
        pc29.Image = pcActiva.Image;
    }
    else
    {
        pc29.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[30]) == 1)
    {
        pc30.Image = pcActiva.Image;
    }
    else
    {
        pc30.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[31]) == 1)
    {
        pc31.Image = pcActiva.Image;
    }
    else
    {
        pc31.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[32]) == 1)
    {
        pc32.Image = pcActiva.Image;
    }
    else
    {
        pc32.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[33]) == 1)
    {
        pc33.Image = pcActiva.Image;
    }
    else
    {
        pc33.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[34]) == 1)
    {
        pc34.Image = pcActiva.Image;
    }
    else
    {
        pc43.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[35]) == 1)
    {
        pc35.Image = pcActiva.Image;
    }
    else
    {
        pc35.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[36]) == 1)
    {
        pc36.Image = pcActiva.Image;
    }
    else
    {
        pc36.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[37]) == 1)
    {
        pc37.Image = pcActiva.Image;
    }
    else
    {
        pc37.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[38]) == 1)
    {
        pc38.Image = pcActiva.Image;
    }
    else
    {
        pc38.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[39]) == 1)
    {
        pc39.Image = pcActiva.Image;
    }
    else
    {
        pc39.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[40]) == 1)
    {
        pc40.Image = pcActiva.Image;
    }
    else
    {
        pc40.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[41]) == 1)
    {
        pc41.Image = pcActiva.Image;
    }
    else
    {
        pc41.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[42]) == 1)
    {
        pc42.Image = pcActiva.Image;
    }
    else
    {
        pc42.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[43]) == 1)
    {
        pc43.Image = pcActiva.Image;
    }
    else
    {
        pc43.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[44]) == 1)
    {
        pc44.Image = pcActiva.Image;
    }
    else
    {
        pc44.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[45]) == 1)
    {
        pc45.Image = pcActiva.Image;
    }
    else
    {
        pc45.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[46]) == 1)
    {
        pc46.Image = pcActiva.Image;
    }
    else
    {
        pc46.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[47]) == 1)
    {
        pc47.Image = pcActiva.Image;
    }
    else
    {
        pc47.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[48]) == 1)
    {
        pc48.Image = pcActiva.Image;
    }
    else
    {
        pc48.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[50]) == 1)
    {
        pc50.Image = pcActiva.Image;
    }
    else
    {
        pc50.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[51]) == 1)
    {
        pc51.Image = pcActiva.Image;
    }
    else
    {
        pc51.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[52]) == 1)
    {
        pc52.Image = pcActiva.Image;
    }
    else
    {
        pc52.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[53]) == 1)
    {
        pc53.Image = pcActiva.Image;
    }
    else
    {
        pc53.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[54]) == 1)
    {
        pc54.Image = pcActiva.Image;
    }
    else
    {
        pc54.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[55]) == 1)
    {
        pc55.Image = pcActiva.Image;
    }
    else
    {
        pc55.Image = pcInactiva.Image;
    }
    if (Convert.ToInt32(Maquina[56]) == 1)
    {
        pc56.Image = pcActiva.Image;
    }
    else
    {
        pc56.Image = pcInactiva.Image;
    } 
}

private void txtCodigo_TextChanged(object sender, EventArgs e)
{
    int conversion = 0;
    int contadorIngresos = 0;
    bool permitirIngresoLista = true;

    if (txtCodigo.Text.Length>=8)
    {
        lblMensaje.Visible = false;
        //VARIABLES
        int contador = 0;
        if(PruebaDevolver==true)
        {
            if (permitirIngresoLista == true)
            {
                if (listaCodigo.Items.Count < 1)
                {
                    int[] ContadorCodigo = new int[1];
                    ContadorCodigo[0] = Convert.ToInt32(txtCodigo.Text);
                    listaCodigo.Items.Add(txtCodigo.Text);
                    contadorCodigosLista++;
                }
                else
                {
                    conversion = listaCodigo.Items.Count + 1;
                    int[] ContadorCodigo = new int[conversion];

                    for (contadorIngresos = 0; contadorIngresos < listaCodigo.Items.Count; contadorIngresos++)
                    {
                        conversion = Convert.ToInt32(listaCodigo.GetItemText(listaCodigo.Items[contadorIngresos]));
                        ContadorCodigo[contadorIngresos] = conversion;
                    }
                    ContadorCodigo[contadorCodigosLista] = Convert.ToInt32(txtCodigo.Text);

                    for (contadorIngresos = 0; contadorIngresos < contadorCodigosLista; contadorIngresos++)
                    {
                        conversion = Convert.ToInt32(txtCodigo.Text);
                        if (conversion == ContadorCodigo[contadorIngresos])
                        {
                            permitirIngresoLista = false;
                        }
                    }

                    if (permitirIngresoLista == true)
                    {
                        listaCodigo.Items.Add(txtCodigo.Text);
                        contadorCodigosLista++;
                    }
                }
            }
        }
        else
        {
            conversion = Convert.ToInt32(txtCodigo.Text);
            SqlConnection conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
            conexion.Open();
            string cadena = "select NoEstudiante, HoraFechaSalida from ingresos where NoEstudiante=" + conversion;
            SqlCommand comando = new SqlCommand(cadena, conexion);
            SqlDataReader registros = comando.ExecuteReader();
            while (registros.Read())
            {
                if (conversion == Convert.ToInt32(registros["NoEstudiante"].ToString()) && registros["HoraFechaSalida"].ToString() == Convert.ToString(0))
                {
                    lblMensaje.Text = "Ese codigo ya esta en uso";
                    lblMensaje.Visible = true;
                    permitirIngresoLista = false;
                }
            }
            conexion.Close();

            if (permitirIngresoLista == true)
            {
                if (listaCodigo.Items.Count < 1)
                {
                    int[] ContadorCodigo = new int[1];
                    ContadorCodigo[0] = Convert.ToInt32(txtCodigo.Text);
                    listaCodigo.Items.Add(txtCodigo.Text);
                    contadorCodigosLista++;
                }
                else
                {
                    conversion = listaCodigo.Items.Count + 1;
                    int[] ContadorCodigo = new int[conversion];

                    for (contadorIngresos = 0; contadorIngresos < listaCodigo.Items.Count; contadorIngresos++)
                    {
                        conversion = Convert.ToInt32(listaCodigo.GetItemText(listaCodigo.Items[contadorIngresos]));
                        ContadorCodigo[contadorIngresos] = conversion;
                    }
                    ContadorCodigo[contadorCodigosLista] = Convert.ToInt32(txtCodigo.Text);

                    for (contadorIngresos = 0; contadorIngresos < contadorCodigosLista; contadorIngresos++)
                    {
                        conversion = Convert.ToInt32(txtCodigo.Text);
                        if (conversion == ContadorCodigo[contadorIngresos])
                        {
                            permitirIngresoLista = false;
                        }
                    }

                    if (permitirIngresoLista == true)
                    {
                        listaCodigo.Items.Add(txtCodigo.Text);
                        contadorCodigosLista++;
                    }
                }
            }

        }
        lblTexto2.Text =Convert.ToString(listaCodigo.Items.Count);
        Codigo = txtCodigo.Text;
        txtCodigo.Text = "";
        txtCodigo.Focus();
    }
}

        private void lblCerrar_MouseEnter(object sender, EventArgs e)
        {
            lblCerrar.ForeColor = Color.Blue;
        }

        private void lblCerrar_MouseLeave(object sender, EventArgs e)
        {
            lblCerrar.ForeColor = Color.White;

        }

        private void lblCerrar_Click(object sender, EventArgs e)
        {
            panelCodigo.Visible = false;
        }

        private void PaginaUsuario_Load(object sender, EventArgs e)
        {
            contadorCodigosLista = 0;
            panelCodigo.Left = this.Width - panelCodigo.Width;
            panelCodigo.Top = 0;
            panelCodigo.Height = this.Height;
            Revision();
            contadorTiempo = 0;
            algo = 0;
            PruebaDevolver = false;
            RevisionPC.Enabled = true;
        }
private void btnDevolver_Click(object sender, EventArgs e)
{
    PruebaDevolver = true;
    if(listaCodigo.Items.Count>0)
    {
        PruebaDevolver = true;
        int contadorIngresos;
        contadorIngresos = listaCodigo.Items.Count;
        int[] ContadorCodigo = new int[contadorIngresos];
        for (contadorIngresos = 0; contadorIngresos < listaCodigo.Items.Count; contadorIngresos++)
        {
            ContadorCodigo[contadorIngresos] = Convert.ToInt32(listaCodigo.GetItemText(listaCodigo.Items[contadorIngresos]));
        }
        //Funcion
        listaCodigo.Items.Clear();
        contadorCodigosLista = 0;
        lblTexto2.Text = "";
        txtCodigo.Focus();
        IngresoCodigo(ContadorCodigo);
    }
    else
    {
        lblMensaje.Text = "No hay datos en la lista";
        lblMensaje.Visible = true;
        txtCodigo.Focus();
    }
}

        private void PaginaUsuario_MouseDown(object sender, MouseEventArgs e)
        {
            TogMove = 1;
            MvalX = e.X;
            MvalY = e.Y;
        }

        private void PaginaUsuario_MouseUp(object sender, MouseEventArgs e)
        {
            TogMove = 0;
        }

        private void PaginaUsuario_MouseMove(object sender, MouseEventArgs e)
        {
            if (TogMove == 1)
            {
                this.SetDesktopLocation(MousePosition.X - MvalX, MousePosition.Y - MvalY);
            }
        }

        private void RevisionPC_Tick(object sender, EventArgs e)
        {
            //VARIABLES
            Revision();
        }

        private void pc1_Click(object sender, EventArgs e)
        {

        }

        private void pc2_Click(object sender, EventArgs e)
        {
        }

        private void pc3_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ACTUALIZAR
            //VARIABLES
            byte DisponibilidadEnVerdadero;
            //INICIALIZAR
            DisponibilidadEnVerdadero = 1;
            /*
            SqlConnection Conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
            Conexion.Open();
            string Cadena = "update MaquinasD set Disponibilidad=" + DisponibilidadEnVerdadero + " where Maquina='" + "Maquina41'";
            SqlCommand Comando = new SqlCommand(Cadena, Conexion);
            int cant;
            cant = Comando.ExecuteNonQuery();
            if (cant == 1)
            {
                MessageBox.Show("Listo la pc esta libre");
            }
            else
            {
                MessageBox.Show("No existe un artículo con el código ingresado");
            }
            //CERRADO DE CONEXION
            Conexion.Close();
           */

            //BORRAR
            /*
            SqlConnection conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
             conexion.Open();
             string cod = "Maquina1";
             string cadena = "delete from ingresos where Nopc='" + cod + "'";
             SqlCommand comando = new SqlCommand(cadena, conexion);
             int cant;
             cant = comando.ExecuteNonQuery();
             if (cant == 1)
             {
                 MessageBox.Show("Se borró el artículo");
             }
             else
                 MessageBox.Show("No existe un artículo con el código ingresado");
             conexion.Close();
             */

            //INSERTAR
            /*
            ContadorMaquinas = 0;
            string nombrepc = "Maquina";
            byte dispo = 1;
            for(ContadorMaquinas=1;ContadorMaquinas<=56;ContadorMaquinas++)
            {
                SqlConnection Conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
                Conexion.Open();
                Cadena = "insert into MaquinasD(Maquina,Disponibilidad) values ('" + nombrepc + ContadorMaquinas + "', " + dispo + ")";
                SqlCommand Comando = new SqlCommand(Cadena, Conexion);
                Comando.ExecuteNonQuery();
                //CERRADO DE CONEXION
                Conexion.Close();
            }
            */
        }

        private void pc4_Click(object sender, EventArgs e)
        {
        }

        private void pc5_Click(object sender, EventArgs e)
        {
        }

        private void pc6_Click(object sender, EventArgs e)
        {
        }

        private void pc7_Click(object sender, EventArgs e)
        {
        }

        private void pc8_Click(object sender, EventArgs e)
        {
        }

        private void pc9_Click(object sender, EventArgs e)
        {
        }

        private void pc10_Click(object sender, EventArgs e)
        {
        }

        private void pc11_Click(object sender, EventArgs e)
        {
        }

        private void pc12_Click(object sender, EventArgs e)
        {
        }

        private void pc13_Click(object sender, EventArgs e)
        {
        }

        private void pc14_Click(object sender, EventArgs e)
        {
        }

        private void pc15_Click(object sender, EventArgs e)
        {
        }

        private void pc16_Click(object sender, EventArgs e)
        {
        }

        private void pc17_Click(object sender, EventArgs e)
        {
        }

        private void pc18_Click(object sender, EventArgs e)
        {
        }

        private void pc19_Click(object sender, EventArgs e)
        {
        }

        private void pc20_Click(object sender, EventArgs e)
        {
        }

        private void pc21_Click(object sender, EventArgs e)
        {
        }

        private void pc22_Click(object sender, EventArgs e)
        {
        }

        private void pc23_Click(object sender, EventArgs e)
        {
        }

        private void pc24_Click(object sender, EventArgs e)
        {
        }

        private void pc25_Click(object sender, EventArgs e)
        {
        }

        private void pc26_Click(object sender, EventArgs e)
        {
        }

        private void pc27_Click(object sender, EventArgs e)
        {
        }

        private void pc28_Click(object sender, EventArgs e)
        {
        }

        private void pc29_Click(object sender, EventArgs e)
        {
        }

        private void pc30_Click(object sender, EventArgs e)
        {
        }

        private void pc31_Click(object sender, EventArgs e)
        {
        }

        private void pc32_Click(object sender, EventArgs e)
        {
        }

        private void pc33_Click(object sender, EventArgs e)
        {
        }

        private void pc34_Click(object sender, EventArgs e)
        {
        }

        private void pc35_Click(object sender, EventArgs e)
        {
        }

        private void pc36_Click(object sender, EventArgs e)
        {
        }

        private void pc37_Click(object sender, EventArgs e)
        {
        }

        private void pc38_Click(object sender, EventArgs e)
        {
        }

        private void pc39_Click(object sender, EventArgs e)
        {
        }

        private void pc40_Click(object sender, EventArgs e)
        {
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==13)
            {
                if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
                {
                    MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Handled = true;
                    return;
                }
                else
                {
                    MessageBox.Show("si se vale");
                }
            }
            
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {

            if(listaCodigo.Items.Count>0)
            {
                int contadorIngresos;
                contadorIngresos = listaCodigo.Items.Count;
                int[] ContadorCodigo = new int[contadorIngresos];
                for (contadorIngresos = 0; contadorIngresos < listaCodigo.Items.Count; contadorIngresos++)
                {
                    ContadorCodigo[contadorIngresos] = Convert.ToInt32(listaCodigo.GetItemText(listaCodigo.Items[contadorIngresos]));
                }
                //Funcion

                IngresoCodigo(ContadorCodigo);
                contadorCodigosLista = 0;
            }
            else
            {
                lblMensaje.Text = "No hay datos en la lista";
                lblMensaje.Visible = true;
                txtCodigo.Focus();
            }
        }

        private void btnQuitar_Click(object sender, EventArgs e)
        {
            if(listaCodigo.Items.Count<=0)
            {
                lblMensaje.Text="No hay nada en la lista";
                lblMensaje.Visible = true;
                txtCodigo.Focus();
            }
            else if(listaCodigo.SelectedIndex <= -1)
            {
                lblMensaje.Text="No hay dato seleccionado";
                lblMensaje.Visible = true;
                txtCodigo.Focus();
            }
            else
            {
                listaCodigo.Items.RemoveAt(listaCodigo.SelectedIndex);
                lblTexto2.Text = Convert.ToString(listaCodigo.Items.Count);
                lblMensaje.Visible = false;
                txtCodigo.Focus();
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            this.Hide();
            frm.Show();
        }
    }
}
