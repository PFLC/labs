﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Centro_de_cumputo
{
    public partial class Form1 : Form
    {
        int TogMove;
        int MvalX;
        int MvalY;

        public Form1()
        {
            InitializeComponent();
        }
        string Nombre, Contra;
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==13)
            {
                txtContra.Focus();
            }
        }

        private void txtContra_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                Nombre = txtNombre.Text;
                Contra = txtContra.Text;
                txtNombre.Text = "";
                txtContra.Text = "";
                if (Nombre=="Jared" && Contra=="123" || Nombre=="CCO" && Contra=="123")
                {
                    /*Pagina2 frm = new Pagina2();
                    this.Hide();
                    frm.Show();*/
                    System.Diagnostics.Process.Start("C:/Program Files (x86)/Microsoft SQL Server/120/Tools/Binn/ManagementStudio/Ssms.exe");
                    txtInstrucciones.Text = "Se requiere tener instalado el motor de base de datos SQL Server." + "\r\n" +
                       "Si aun no lo tiene instalado o hay algun problema en que no se pueda abrir siga las siguientes instrucciones." +
                       " http://www.tutorialesprogramacionya.com/csharpya/detalleconcepto.php?codigo=199&inicio=60" + "\r\n" +
                       "Para realizar consultas:" + "\r\n" +
                       "Click en conectar, pestaña base de datos, laboratorio, tablas y luego seleccione una de las" + "\r\n" +
                       "tablas que desea consultar, dele click derecho y en seleccionar las primeras 1000 filas." + "\r\n" +
                       "Para editar:" + "\r\n" +
                       "Click en conectar, pestaña base de datos, laboratorio, tablas y luego seleccione una de las" + "\r\n" +
                       "tablas que desea consultar, dele click derecho y en editar las primeras 200 filas.";


                    panelInstrucciones.Left = 450;
                    panelInstrucciones.Top = 150;
                    panelInstrucciones.Width = txtInstrucciones.Width;
                    panelInstrucciones.Height = txtInstrucciones.Height;
                    btnPAceptar.Top = txtInstrucciones.Height - btnPAceptar.Height;
                    btnPAceptar.Left = txtInstrucciones.Width - btnPAceptar.Width;
                    panelInstrucciones.Visible = true;
                }
                else
                {
                    PaginaUsuario frm = new PaginaUsuario();
                    this.Hide();
                    frm.Show();
                }
            }
        }

        private void FiguraAceptar_Click(object sender, EventArgs e)
        {
            Nombre = txtNombre.Text;
            Contra = txtContra.Text;
            if (Nombre == "Jared" && Contra == "123" || Nombre == "CCO" && Contra == "123")
            {
                txtNombre.Text = "";
                txtContra.Text = "";
                /*Pagina2 frm = new Pagina2();
                this.Hide();
                frm.Show();*/
                System.Diagnostics.Process.Start("C:/Program Files (x86)/Microsoft SQL Server/120/Tools/Binn/ManagementStudio/Ssms.exe");
                txtInstrucciones.Text = "Se requiere tener instalado el motor de base de datos SQL Server." + "\r\n" +
                   "Si aun no lo tiene instalado o hay algun problema en que no se pueda abrir siga las siguientes instrucciones." +
                   " http://www.tutorialesprogramacionya.com/csharpya/detalleconcepto.php?codigo=199&inicio=60" + "\r\n" +
                   "Para realizar consultas:" + "\r\n" +
                   "Click en conectar, pestaña base de datos, laboratorio, tablas y luego seleccione una de las" + "\r\n" +
                   "tablas que desea consultar, dele click derecho y en seleccionar las primeras 1000 filas." + "\r\n" +
                   "Para editar:" + "\r\n" +
                   "Click en conectar, pestaña base de datos, laboratorio, tablas y luego seleccione una de las" + "\r\n" +
                   "tablas que desea consultar, dele click derecho y en editar las primeras 200 filas.";
                

                panelInstrucciones.Left = 450;
                panelInstrucciones.Top = 150;
                panelInstrucciones.Width = txtInstrucciones.Width;
                panelInstrucciones.Height =txtInstrucciones.Height;
                btnPAceptar.Top = txtInstrucciones.Height - btnPAceptar.Height;
                btnPAceptar.Left = txtInstrucciones.Width - btnPAceptar.Width;
                panelInstrucciones.Visible = true;
            }
            else
            {
                PaginaUsuario frm = new PaginaUsuario();
                this.Hide();
                frm.Show();
            }

        }

        private void lblCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void lblCerrar_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void lblCerrar_MouseEnter(object sender, EventArgs e)
        {
            lblCerrar.BackColor = Color.Red;
        }

        private void lblCerrar_MouseLeave(object sender, EventArgs e)
        {
            lblCerrar.BackColor = Color.Transparent;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            TogMove = 1;
            MvalX = e.X;
            MvalY = e.Y;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            TogMove = 0;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if(TogMove==1)
            {
                this.SetDesktopLocation(MousePosition.X - MvalX, MousePosition.Y - MvalY);
            }
        }

        private void Tiempo_Tick(object sender, EventArgs e)
        {
            DateTime Hoy = DateTime.Today;
            string fecha_actual = Hoy.ToString("dd-MM-yyyy");
            lblHora.Text = DateTime.Now.ToShortTimeString();
        }

        private void btnPAceptar_Click(object sender, EventArgs e)
        {
            panelInstrucciones.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblCerrar.Top = 0;
            lblCerrar.Left = this.Width - lblCerrar.Width;
            lblTexto1.Left = (this.Width / 2)-(lblTexto1.Width/2);
            lblTexto2.Left = (this.Width / 2) - (lblTexto2.Width/2);
            txtNombre.Left = lblTexto1.Left;
            txtContra.Left = lblTexto1.Left;
            FiguraAceptar.Left = (this.Width / 2)-85;
            FiguraAceptar.Top = 400;
            lblTexto1.Top = 140;
            txtNombre.Top = 180;
            lblTexto2.Top = 230;
            txtContra.Top = 270;
            lblHora.Left = this.Width - 100;
            lblHora.Top = this.Height - 50;
        }
    }
}
