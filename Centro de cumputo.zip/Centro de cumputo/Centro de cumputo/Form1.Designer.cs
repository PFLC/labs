﻿namespace Centro_de_cumputo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtContra = new System.Windows.Forms.TextBox();
            this.FiguraAceptar = new System.Windows.Forms.PictureBox();
            this.lblTexto1 = new System.Windows.Forms.Label();
            this.lblTexto2 = new System.Windows.Forms.Label();
            this.lblCerrar = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.Tiempo = new System.Windows.Forms.Timer(this.components);
            this.panelInstrucciones = new System.Windows.Forms.Panel();
            this.btnPAceptar = new System.Windows.Forms.Button();
            this.txtInstrucciones = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.FiguraAceptar)).BeginInit();
            this.panelInstrucciones.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNombre
            // 
            this.txtNombre.CausesValidation = false;
            this.txtNombre.Font = new System.Drawing.Font("Arial Narrow", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.ForeColor = System.Drawing.Color.Magenta;
            this.txtNombre.Location = new System.Drawing.Point(374, 143);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(195, 32);
            this.txtNombre.TabIndex = 1;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // txtContra
            // 
            this.txtContra.Font = new System.Drawing.Font("Arial Narrow", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContra.ForeColor = System.Drawing.Color.Magenta;
            this.txtContra.Location = new System.Drawing.Point(374, 231);
            this.txtContra.Name = "txtContra";
            this.txtContra.Size = new System.Drawing.Size(195, 32);
            this.txtContra.TabIndex = 2;
            this.txtContra.UseSystemPasswordChar = true;
            this.txtContra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContra_KeyPress);
            // 
            // FiguraAceptar
            // 
            this.FiguraAceptar.BackColor = System.Drawing.Color.Transparent;
            this.FiguraAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FiguraAceptar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FiguraAceptar.Image = global::Centro_de_cumputo.Properties.Resources.Knapp;
            this.FiguraAceptar.Location = new System.Drawing.Point(414, 286);
            this.FiguraAceptar.Name = "FiguraAceptar";
            this.FiguraAceptar.Size = new System.Drawing.Size(140, 140);
            this.FiguraAceptar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.FiguraAceptar.TabIndex = 3;
            this.FiguraAceptar.TabStop = false;
            this.FiguraAceptar.Click += new System.EventHandler(this.FiguraAceptar_Click);
            // 
            // lblTexto1
            // 
            this.lblTexto1.BackColor = System.Drawing.Color.Transparent;
            this.lblTexto1.Font = new System.Drawing.Font("Book Antiqua", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto1.Location = new System.Drawing.Point(368, 103);
            this.lblTexto1.Name = "lblTexto1";
            this.lblTexto1.Size = new System.Drawing.Size(205, 35);
            this.lblTexto1.TabIndex = 4;
            this.lblTexto1.Text = "Usuario";
            // 
            // lblTexto2
            // 
            this.lblTexto2.BackColor = System.Drawing.Color.Transparent;
            this.lblTexto2.Font = new System.Drawing.Font("Book Antiqua", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto2.Location = new System.Drawing.Point(368, 197);
            this.lblTexto2.Name = "lblTexto2";
            this.lblTexto2.Size = new System.Drawing.Size(205, 35);
            this.lblTexto2.TabIndex = 5;
            this.lblTexto2.Text = "Contraseña";
            // 
            // lblCerrar
            // 
            this.lblCerrar.BackColor = System.Drawing.Color.Transparent;
            this.lblCerrar.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblCerrar.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCerrar.ForeColor = System.Drawing.Color.White;
            this.lblCerrar.Location = new System.Drawing.Point(1531, 9);
            this.lblCerrar.Name = "lblCerrar";
            this.lblCerrar.Size = new System.Drawing.Size(50, 30);
            this.lblCerrar.TabIndex = 6;
            this.lblCerrar.Text = "X";
            this.lblCerrar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCerrar.Click += new System.EventHandler(this.lblCerrar_Click);
            this.lblCerrar.MouseEnter += new System.EventHandler(this.lblCerrar_MouseEnter);
            this.lblCerrar.MouseLeave += new System.EventHandler(this.lblCerrar_MouseLeave);
            this.lblCerrar.MouseHover += new System.EventHandler(this.lblCerrar_MouseHover);
            // 
            // lblHora
            // 
            this.lblHora.BackColor = System.Drawing.Color.Transparent;
            this.lblHora.Font = new System.Drawing.Font("Nirmala UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.ForeColor = System.Drawing.Color.MintCream;
            this.lblHora.Location = new System.Drawing.Point(818, 597);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(127, 58);
            this.lblHora.TabIndex = 7;
            this.lblHora.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tiempo
            // 
            this.Tiempo.Enabled = true;
            this.Tiempo.Tick += new System.EventHandler(this.Tiempo_Tick);
            // 
            // panelInstrucciones
            // 
            this.panelInstrucciones.Controls.Add(this.btnPAceptar);
            this.panelInstrucciones.Controls.Add(this.txtInstrucciones);
            this.panelInstrucciones.Location = new System.Drawing.Point(593, 23);
            this.panelInstrucciones.Name = "panelInstrucciones";
            this.panelInstrucciones.Size = new System.Drawing.Size(904, 620);
            this.panelInstrucciones.TabIndex = 8;
            this.panelInstrucciones.Visible = false;
            // 
            // btnPAceptar
            // 
            this.btnPAceptar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnPAceptar.FlatAppearance.BorderSize = 0;
            this.btnPAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPAceptar.Location = new System.Drawing.Point(625, 545);
            this.btnPAceptar.Name = "btnPAceptar";
            this.btnPAceptar.Size = new System.Drawing.Size(133, 72);
            this.btnPAceptar.TabIndex = 9;
            this.btnPAceptar.Text = "Aceptar";
            this.btnPAceptar.UseVisualStyleBackColor = false;
            this.btnPAceptar.Click += new System.EventHandler(this.btnPAceptar_Click);
            // 
            // txtInstrucciones
            // 
            this.txtInstrucciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInstrucciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInstrucciones.Location = new System.Drawing.Point(3, 0);
            this.txtInstrucciones.Multiline = true;
            this.txtInstrucciones.Name = "txtInstrucciones";
            this.txtInstrucciones.ReadOnly = true;
            this.txtInstrucciones.Size = new System.Drawing.Size(820, 526);
            this.txtInstrucciones.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Centro_de_cumputo.Properties.Resources.gradient;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panelInstrucciones);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.lblCerrar);
            this.Controls.Add(this.lblTexto2);
            this.Controls.Add(this.lblTexto1);
            this.Controls.Add(this.FiguraAceptar);
            this.Controls.Add(this.txtContra);
            this.Controls.Add(this.txtNombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.FiguraAceptar)).EndInit();
            this.panelInstrucciones.ResumeLayout(false);
            this.panelInstrucciones.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtContra;
        private System.Windows.Forms.PictureBox FiguraAceptar;
        private System.Windows.Forms.Label lblTexto1;
        private System.Windows.Forms.Label lblTexto2;
        private System.Windows.Forms.Label lblCerrar;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Timer Tiempo;
        private System.Windows.Forms.Panel panelInstrucciones;
        private System.Windows.Forms.TextBox txtInstrucciones;
        private System.Windows.Forms.Button btnPAceptar;
    }
}

