﻿namespace Centro_de_cumputo
{
    partial class Pagina2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.btnMInicio = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnMHerramientas = new System.Windows.Forms.ToolStripMenuItem();
            this.crearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.conectarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tablasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opcionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelOpciones = new System.Windows.Forms.Panel();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.panelRgistros = new System.Windows.Forms.Panel();
            this.tabBuscar = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnBusqueda1 = new System.Windows.Forms.Button();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnBusqueda2 = new System.Windows.Forms.Button();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnBusqueda3 = new System.Windows.Forms.Button();
            this.txtGrupo = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnBusqueda4 = new System.Windows.Forms.Button();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnBusqueda5 = new System.Windows.Forms.Button();
            this.txtPc = new System.Windows.Forms.TextBox();
            this.btnConsultas = new System.Windows.Forms.Button();
            this.btnRegistros = new System.Windows.Forms.Button();
            this.splitLateral = new System.Windows.Forms.Splitter();
            this.lblHora = new System.Windows.Forms.Label();
            this.tiempo2 = new System.Windows.Forms.Timer(this.components);
            this.panelSeleccion = new System.Windows.Forms.Panel();
            this.splitBajo = new System.Windows.Forms.Splitter();
            this.listaRegistros = new System.Windows.Forms.ListView();
            this.Col1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1.SuspendLayout();
            this.panelOpciones.SuspendLayout();
            this.panelRgistros.SuspendLayout();
            this.tabBuscar.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnMInicio,
            this.btnMHerramientas,
            this.verToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1600, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // btnMInicio
            // 
            this.btnMInicio.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.btnMInicio.Name = "btnMInicio";
            this.btnMInicio.Size = new System.Drawing.Size(48, 20);
            this.btnMInicio.Text = "Inicio";
            // 
            // nuevoToolStripMenuItem
            // 
            this.nuevoToolStripMenuItem.Name = "nuevoToolStripMenuItem";
            this.nuevoToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.nuevoToolStripMenuItem.Text = "Nuevo";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // btnMHerramientas
            // 
            this.btnMHerramientas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crearToolStripMenuItem,
            this.borrarToolStripMenuItem,
            this.toolStripSeparator1,
            this.conectarToolStripMenuItem});
            this.btnMHerramientas.Name = "btnMHerramientas";
            this.btnMHerramientas.Size = new System.Drawing.Size(90, 20);
            this.btnMHerramientas.Text = "Herramientas";
            // 
            // crearToolStripMenuItem
            // 
            this.crearToolStripMenuItem.Name = "crearToolStripMenuItem";
            this.crearToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.crearToolStripMenuItem.Text = "Crear";
            // 
            // borrarToolStripMenuItem
            // 
            this.borrarToolStripMenuItem.Name = "borrarToolStripMenuItem";
            this.borrarToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.borrarToolStripMenuItem.Text = "Borrar";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(119, 6);
            // 
            // conectarToolStripMenuItem
            // 
            this.conectarToolStripMenuItem.Name = "conectarToolStripMenuItem";
            this.conectarToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.conectarToolStripMenuItem.Text = "Conectar";
            this.conectarToolStripMenuItem.Click += new System.EventHandler(this.conectarToolStripMenuItem_Click);
            // 
            // verToolStripMenuItem
            // 
            this.verToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.panelToolStripMenuItem,
            this.tablasToolStripMenuItem,
            this.opcionesToolStripMenuItem});
            this.verToolStripMenuItem.Name = "verToolStripMenuItem";
            this.verToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.verToolStripMenuItem.Text = "Ver";
            // 
            // panelToolStripMenuItem
            // 
            this.panelToolStripMenuItem.Name = "panelToolStripMenuItem";
            this.panelToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.panelToolStripMenuItem.Text = "Panel";
            // 
            // tablasToolStripMenuItem
            // 
            this.tablasToolStripMenuItem.Name = "tablasToolStripMenuItem";
            this.tablasToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.tablasToolStripMenuItem.Text = "Tablas";
            // 
            // opcionesToolStripMenuItem
            // 
            this.opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            this.opcionesToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.opcionesToolStripMenuItem.Text = "Opciones";
            // 
            // panelOpciones
            // 
            this.panelOpciones.BackColor = System.Drawing.Color.Lime;
            this.panelOpciones.Controls.Add(this.btnAgregar);
            this.panelOpciones.Controls.Add(this.btnBuscar);
            this.panelOpciones.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelOpciones.Location = new System.Drawing.Point(0, 24);
            this.panelOpciones.Name = "panelOpciones";
            this.panelOpciones.Size = new System.Drawing.Size(173, 876);
            this.panelOpciones.TabIndex = 2;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(12, 380);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 11;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(12, 351);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 13;
            this.btnBuscar.Text = "Busqueda";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // panelRgistros
            // 
            this.panelRgistros.BackColor = System.Drawing.Color.Aqua;
            this.panelRgistros.Controls.Add(this.listaRegistros);
            this.panelRgistros.Controls.Add(this.tabBuscar);
            this.panelRgistros.Controls.Add(this.btnConsultas);
            this.panelRgistros.Controls.Add(this.btnRegistros);
            this.panelRgistros.Location = new System.Drawing.Point(180, 24);
            this.panelRgistros.Name = "panelRgistros";
            this.panelRgistros.Size = new System.Drawing.Size(1420, 456);
            this.panelRgistros.TabIndex = 6;
            // 
            // tabBuscar
            // 
            this.tabBuscar.Controls.Add(this.tabPage1);
            this.tabBuscar.Controls.Add(this.tabPage2);
            this.tabBuscar.Controls.Add(this.tabPage3);
            this.tabBuscar.Controls.Add(this.tabPage4);
            this.tabBuscar.Controls.Add(this.tabPage5);
            this.tabBuscar.Location = new System.Drawing.Point(6, 314);
            this.tabBuscar.Name = "tabBuscar";
            this.tabBuscar.SelectedIndex = 0;
            this.tabBuscar.Size = new System.Drawing.Size(742, 126);
            this.tabBuscar.TabIndex = 3;
            this.tabBuscar.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnBusqueda1);
            this.tabPage1.Controls.Add(this.lblNombre);
            this.tabPage1.Controls.Add(this.txtNombre);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(734, 100);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Por nombre";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnBusqueda1
            // 
            this.btnBusqueda1.Location = new System.Drawing.Point(279, 8);
            this.btnBusqueda1.Name = "btnBusqueda1";
            this.btnBusqueda1.Size = new System.Drawing.Size(75, 23);
            this.btnBusqueda1.TabIndex = 14;
            this.btnBusqueda1.Text = "Buscar";
            this.btnBusqueda1.UseVisualStyleBackColor = true;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft YaHei", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(3, 4);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(87, 25);
            this.lblNombre.TabIndex = 1;
            this.lblNombre.Text = "Nombre";
            // 
            // txtNombre
            // 
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(93, 6);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(180, 23);
            this.txtNombre.TabIndex = 0;
            this.txtNombre.Text = "nombre";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnBusqueda2);
            this.tabPage2.Controls.Add(this.txtCodigo);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(734, 100);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Por codigo";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnBusqueda2
            // 
            this.btnBusqueda2.Location = new System.Drawing.Point(403, 6);
            this.btnBusqueda2.Name = "btnBusqueda2";
            this.btnBusqueda2.Size = new System.Drawing.Size(75, 23);
            this.btnBusqueda2.TabIndex = 15;
            this.btnBusqueda2.Text = "Buscar";
            this.btnBusqueda2.UseVisualStyleBackColor = true;
            // 
            // txtCodigo
            // 
            this.txtCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigo.Location = new System.Drawing.Point(93, 6);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(180, 23);
            this.txtCodigo.TabIndex = 2;
            this.txtCodigo.Text = "codigo";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnBusqueda3);
            this.tabPage3.Controls.Add(this.txtGrupo);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(734, 100);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Por Grupo";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnBusqueda3
            // 
            this.btnBusqueda3.Location = new System.Drawing.Point(415, 6);
            this.btnBusqueda3.Name = "btnBusqueda3";
            this.btnBusqueda3.Size = new System.Drawing.Size(75, 23);
            this.btnBusqueda3.TabIndex = 15;
            this.btnBusqueda3.Text = "Buscar";
            this.btnBusqueda3.UseVisualStyleBackColor = true;
            // 
            // txtGrupo
            // 
            this.txtGrupo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrupo.Location = new System.Drawing.Point(93, 6);
            this.txtGrupo.Name = "txtGrupo";
            this.txtGrupo.Size = new System.Drawing.Size(180, 23);
            this.txtGrupo.TabIndex = 3;
            this.txtGrupo.Text = "grupo";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnBusqueda4);
            this.tabPage4.Controls.Add(this.txtHora);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(734, 100);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Por hora";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnBusqueda4
            // 
            this.btnBusqueda4.Location = new System.Drawing.Point(426, 6);
            this.btnBusqueda4.Name = "btnBusqueda4";
            this.btnBusqueda4.Size = new System.Drawing.Size(75, 23);
            this.btnBusqueda4.TabIndex = 15;
            this.btnBusqueda4.Text = "Buscar";
            this.btnBusqueda4.UseVisualStyleBackColor = true;
            // 
            // txtHora
            // 
            this.txtHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHora.Location = new System.Drawing.Point(93, 6);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(180, 23);
            this.txtHora.TabIndex = 11;
            this.txtHora.Text = "hora";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnBusqueda5);
            this.tabPage5.Controls.Add(this.txtPc);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(734, 100);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Por pc";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnBusqueda5
            // 
            this.btnBusqueda5.Location = new System.Drawing.Point(474, 6);
            this.btnBusqueda5.Name = "btnBusqueda5";
            this.btnBusqueda5.Size = new System.Drawing.Size(75, 23);
            this.btnBusqueda5.TabIndex = 15;
            this.btnBusqueda5.Text = "Buscar";
            this.btnBusqueda5.UseVisualStyleBackColor = true;
            // 
            // txtPc
            // 
            this.txtPc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPc.Location = new System.Drawing.Point(116, 6);
            this.txtPc.Name = "txtPc";
            this.txtPc.Size = new System.Drawing.Size(180, 23);
            this.txtPc.TabIndex = 12;
            this.txtPc.Text = "pc";
            // 
            // btnConsultas
            // 
            this.btnConsultas.BackColor = System.Drawing.Color.Coral;
            this.btnConsultas.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnConsultas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsultas.Location = new System.Drawing.Point(77, 0);
            this.btnConsultas.Name = "btnConsultas";
            this.btnConsultas.Size = new System.Drawing.Size(75, 25);
            this.btnConsultas.TabIndex = 1;
            this.btnConsultas.Text = "Consultas";
            this.btnConsultas.UseVisualStyleBackColor = false;
            this.btnConsultas.Click += new System.EventHandler(this.btnConsultas_Click);
            // 
            // btnRegistros
            // 
            this.btnRegistros.BackColor = System.Drawing.Color.Coral;
            this.btnRegistros.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnRegistros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistros.Location = new System.Drawing.Point(3, 0);
            this.btnRegistros.Name = "btnRegistros";
            this.btnRegistros.Size = new System.Drawing.Size(75, 25);
            this.btnRegistros.TabIndex = 0;
            this.btnRegistros.Text = "Registros";
            this.btnRegistros.UseVisualStyleBackColor = false;
            this.btnRegistros.Click += new System.EventHandler(this.btnRegistros_Click);
            // 
            // splitLateral
            // 
            this.splitLateral.BackColor = System.Drawing.Color.Plum;
            this.splitLateral.Location = new System.Drawing.Point(173, 24);
            this.splitLateral.MinExtra = 500;
            this.splitLateral.MinSize = 150;
            this.splitLateral.Name = "splitLateral";
            this.splitLateral.Size = new System.Drawing.Size(7, 876);
            this.splitLateral.TabIndex = 7;
            this.splitLateral.TabStop = false;
            this.splitLateral.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitLateral_SplitterMoved);
            // 
            // lblHora
            // 
            this.lblHora.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblHora.Font = new System.Drawing.Font("Nirmala UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.lblHora.Location = new System.Drawing.Point(862, 0);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(100, 24);
            this.lblHora.TabIndex = 8;
            this.lblHora.Text = "dfsdfs";
            this.lblHora.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tiempo2
            // 
            this.tiempo2.Enabled = true;
            this.tiempo2.Tick += new System.EventHandler(this.tiempo2_Tick);
            // 
            // panelSeleccion
            // 
            this.panelSeleccion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panelSeleccion.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelSeleccion.Location = new System.Drawing.Point(180, 759);
            this.panelSeleccion.Name = "panelSeleccion";
            this.panelSeleccion.Size = new System.Drawing.Size(1420, 141);
            this.panelSeleccion.TabIndex = 9;
            // 
            // splitBajo
            // 
            this.splitBajo.BackColor = System.Drawing.Color.Plum;
            this.splitBajo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitBajo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitBajo.Location = new System.Drawing.Point(180, 752);
            this.splitBajo.MinExtra = 350;
            this.splitBajo.MinSize = 120;
            this.splitBajo.Name = "splitBajo";
            this.splitBajo.Size = new System.Drawing.Size(1420, 7);
            this.splitBajo.TabIndex = 10;
            this.splitBajo.TabStop = false;
            this.splitBajo.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitBajo_SplitterMoved_1);
            // 
            // listaRegistros
            // 
            this.listaRegistros.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Col1,
            this.col2,
            this.col3,
            this.col4});
            this.listaRegistros.FullRowSelect = true;
            this.listaRegistros.GridLines = true;
            this.listaRegistros.Location = new System.Drawing.Point(3, 31);
            this.listaRegistros.Name = "listaRegistros";
            this.listaRegistros.Size = new System.Drawing.Size(1414, 422);
            this.listaRegistros.TabIndex = 15;
            this.listaRegistros.UseCompatibleStateImageBehavior = false;
            this.listaRegistros.View = System.Windows.Forms.View.Details;
            // 
            // Col1
            // 
            this.Col1.Text = "No. Estudiante";
            this.Col1.Width = 109;
            // 
            // col2
            // 
            this.col2.Text = "No. PC";
            this.col2.Width = 87;
            // 
            // col3
            // 
            this.col3.Text = "Hora de entrada";
            this.col3.Width = 151;
            // 
            // col4
            // 
            this.col4.Text = "Hora de salida";
            this.col4.Width = 157;
            // 
            // Pagina2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Centro_de_cumputo.Properties.Resources.gradient1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.splitBajo);
            this.Controls.Add(this.panelSeleccion);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.splitLateral);
            this.Controls.Add(this.panelOpciones);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panelRgistros);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Pagina2";
            this.Text = "Pagina2";
            this.Load += new System.EventHandler(this.Pagina2_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pagina2_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Pagina2_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Pagina2_MouseUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelOpciones.ResumeLayout(false);
            this.panelRgistros.ResumeLayout(false);
            this.tabBuscar.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btnMInicio;
        private System.Windows.Forms.ToolStripMenuItem nuevoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnMHerramientas;
        private System.Windows.Forms.ToolStripMenuItem crearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borrarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem panelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tablasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem opcionesToolStripMenuItem;
        private System.Windows.Forms.Panel panelOpciones;
        private System.Windows.Forms.Panel panelRgistros;
        private System.Windows.Forms.Button btnConsultas;
        private System.Windows.Forms.Button btnRegistros;
        private System.Windows.Forms.Splitter splitLateral;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Timer tiempo2;
        private System.Windows.Forms.Panel panelSeleccion;
        private System.Windows.Forms.Splitter splitBajo;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.TabControl tabBuscar;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtGrupo;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox txtPc;
        private System.Windows.Forms.Button btnBusqueda1;
        private System.Windows.Forms.Button btnBusqueda2;
        private System.Windows.Forms.Button btnBusqueda3;
        private System.Windows.Forms.Button btnBusqueda4;
        private System.Windows.Forms.Button btnBusqueda5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem conectarToolStripMenuItem;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.ListView listaRegistros;
        private System.Windows.Forms.ColumnHeader Col1;
        private System.Windows.Forms.ColumnHeader col2;
        private System.Windows.Forms.ColumnHeader col3;
        private System.Windows.Forms.ColumnHeader col4;
    }
}