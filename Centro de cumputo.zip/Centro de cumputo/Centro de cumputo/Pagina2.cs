﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Centro_de_cumputo
{
    public partial class Pagina2 : Form
    {
        int TogMove;
        int MvalX;
        int MvalY;
        public Pagina2()
        {
            InitializeComponent();
        }

        private void Pagina2_Load(object sender, EventArgs e)
        {
            lblHora.Top = 0;
            lblHora.Left = this.Width - lblHora.Width;
            panelRgistros.Width = this.Width - (panelOpciones.Left + panelOpciones.Width);
            panelRgistros.Left = panelOpciones.Left + panelOpciones.Width;
            panelRgistros.Height = panelSeleccion.Top-15;
            listaRegistros.Left = btnRegistros.Left;
            listaRegistros.Top = btnRegistros.Top + btnRegistros.Height;
            listaRegistros.Height = panelRgistros.Top + panelRgistros.Height;
            //panelSeleccion.Top = this.Height - panelSeleccion.Height;
            //panelSeleccion.Left = panelOpciones.Left + panelOpciones.Width +3;
        }

        private void lblSalir_Click(object sender, EventArgs e)
        {
            
        }

        private void Pagina2_MouseDown(object sender, MouseEventArgs e)
        {
            TogMove = 1;
            MvalX = e.X;
            MvalY = e.Y;
        }

        private void Pagina2_MouseUp(object sender, MouseEventArgs e)
        {
            TogMove = 0;
        }

        private void Pagina2_MouseMove(object sender, MouseEventArgs e)
        {
            if (TogMove == 1)
            {
                this.SetDesktopLocation(MousePosition.X - MvalX, MousePosition.Y - MvalY);
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.Show();
        }

        private void lblCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm = new Form1();
            frm.Show();
        }

        private void splitLateral_SplitterMoved(object sender, SplitterEventArgs e)
        {
            panelRgistros.Left = panelOpciones.Left + panelOpciones.Width;
            panelRgistros.Width = this.Width - (panelOpciones.Left + panelOpciones.Width);
            //panelSeleccion.Left = panelOpciones.Left + panelOpciones.Width+3;
        }

        private void tiempo2_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToShortTimeString();
        }

        private void splitBajo_SplitterMoved_1(object sender, SplitterEventArgs e)
        {
            panelRgistros.Height = panelSeleccion.Top;
            listaRegistros.Height = panelSeleccion.Top;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            tabBuscar.Left = panelOpciones.Left + 3;
            tabBuscar.Top = panelSeleccion.Top;
            tabBuscar.Visible = true;
        }

        private void conectarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
            conexion.Open();
            MessageBox.Show("Se abrió la conexión con el servidor SQL Server y se seleccionó la base de datos");
            conexion.Close();
            MessageBox.Show("Se cerró la conexión.");
        }

        private void btnConsultas_Click(object sender, EventArgs e)
        {
            string NoEstudiante = "";
            string NoMaquina = "";
            string HoraEntrada = "";
            string HoraSalida = "";

            SqlConnection conexion = new SqlConnection("server=CCO02PC\\SQLEXPRESS ; database=laboratorio ; integrated security = true");
            conexion.Open();
            string cadena = "select NoEstudiante, Nopc, HoraFechaEntrada, HoraFechaSalida from ingresos";
            SqlCommand comando = new SqlCommand(cadena, conexion);
            SqlDataReader registros = comando.ExecuteReader();
            while (registros.Read())
            {
                NoEstudiante = registros["NoEstudiante"].ToString();
                NoMaquina = registros["Nopc"].ToString();
                HoraEntrada = registros["HoraFechaEntrada"].ToString();
                HoraSalida= registros["HoraFechaSalida"].ToString();

                ListViewItem lista1 = new ListViewItem(NoEstudiante);
                lista1.SubItems.Add(NoMaquina);
                lista1.SubItems.Add(HoraEntrada);
                lista1.SubItems.Add(HoraSalida);
                listaRegistros.Items.Add(lista1);
            }
            conexion.Close();
        }

        private void btnRegistros_Click(object sender, EventArgs e)
        {

        }
    }
}
